const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const store = require('./data/store');
const TicketModel = require('./models/Ticket');
const auth = require('./auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure upload directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'photo-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed.'));
    }
  }
});

// Middleware
// Same-origin app: no cross-origin credential access is needed.
app.use(cors({ origin: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(auth.sessionMiddleware);

// Serve static frontend and uploads
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// Initialize DB
store.initDB();

// Account registration is always a standard user account. Elevated roles are never client-selectable.
app.post('/api/auth/register', async (req, res) => {
  try {
    const user = await auth.register(req.body || {});
    const token = auth.createSession(user);
    auth.setSessionCookie(res, token, req.secure);
    res.status(201).json({ success: true, data: auth.publicUser(user) });
  } catch (err) { res.status(err.status || 500).json({ success: false, message: err.status ? err.message : 'Could not create account.' }); }
});
app.post('/api/auth/login', async (req, res) => {
  try {
    const user = await auth.login(req.body?.email, req.body?.password);
    auth.setSessionCookie(res, auth.createSession(user), req.secure);
    res.json({ success: true, data: auth.publicUser(user) });
  } catch (err) { res.status(err.status || 500).json({ success: false, message: err.status ? err.message : 'Could not sign in.' }); }
});
app.get('/api/auth/me', (req, res) => res.json({ success: true, data: req.user || null }));
app.post('/api/auth/logout', (req, res) => { auth.revokeSession(req); auth.clearSessionCookie(res, req.secure); res.json({ success: true }); });
app.get('/api/auth/users', auth.requireRoles('admin'), (req, res) => res.json({ success: true, data: auth.listUsers() }));
app.post('/api/auth/users', auth.requireRoles('admin'), async (req, res) => {
  try { const user = await auth.createManagedUser(req.body || {}); res.status(201).json({ success: true, data: auth.publicUser(user) }); }
  catch (err) { res.status(err.status || 500).json({ success: false, message: err.status ? err.message : 'Could not create account.' }); }
});

// ================= API ROUTES =================

// 1. Get Summary Stats
app.get('/api/stats', (req, res) => {
  try {
    const stats = store.getStats();
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Get All Poles
app.get('/api/poles', (req, res) => {
  try {
    const poles = store.getPoles();
    res.json({ success: true, data: poles });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Add a New Pole
app.post('/api/poles', auth.requireRoles('admin'), (req, res) => {
  try {
    const newPole = store.addPole(req.body);
    res.status(201).json({ success: true, data: newPole });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Get Technicians
app.get('/api/technicians', (req, res) => {
  try {
    const technicians = store.getTechnicians();
    res.json({ success: true, data: technicians.map(({ id, name, designation, ward, campusLocation, skills, status }) => ({ id, name, designation, ward, campusLocation, skills, status })) });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ================= TICKET MODEL REST API =================

// 5. Get Tickets / Complaints (Supports Canonical Ticket filters & legacy filters)
const handleGetTickets = (req, res) => {
  try {
    const { status, wardZone, ward, urgencyLevel, priority, search } = req.query;
    const tickets = store.getComplaints({ 
      status, 
      ward: wardZone || ward, 
      priority: urgencyLevel || priority, 
      search 
    });
    res.json({ success: true, data: tickets, count: tickets.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.get('/api/tickets', auth.requireRoles('admin', 'technician'), handleGetTickets);
app.get('/api/complaints', auth.requireRoles('admin', 'technician'), handleGetTickets);
app.get('/api/my/tickets', auth.requireRoles('user'), (req, res) => {
  try { const tickets = store.getComplaints().filter(ticket => ticket.ownerUserId === req.user.id); res.json({ success: true, data: tickets }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// 6. Get Ticket by ID or Citizen/Reporter Phone
const handleGetTicketById = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const ticket = store.getComplaintByTicket(id);
    if (!ticket) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    if (!req.user || (!['admin', 'technician'].includes(req.user.role) && ticket.ownerUserId !== req.user.id)) {
      return res.status(403).json({ success: false, message: 'Sign in with the account that filed this ticket to view its details.' });
    }
    res.json({ success: true, data: ticket });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.get('/api/tickets/:id', auth.requireAuth, handleGetTicketById);
app.get('/api/complaints/:ticketId', auth.requireAuth, handleGetTicketById);

// 7. Create New Ticket (Supports multipart photo upload or JSON)
const handleCreateTicket = (req, res) => {
  try {
    const ticketData = { ...req.body };
    if (req.file) {
      ticketData.photoUrl = `/uploads/${req.file.filename}`;
    }

    // Parse coordinates or location if passed as string
    if (typeof ticketData.location === 'string') {
      try { ticketData.location = JSON.parse(ticketData.location); } catch (e) {}
    }
    if (typeof ticketData.reporter === 'string') {
      try { ticketData.reporter = JSON.parse(ticketData.reporter); } catch (e) {}
    }
    if (req.user) ticketData.ownerUserId = req.user.id;

    const created = store.createComplaint(ticketData);
    res.status(201).json({ 
      success: true, 
      message: 'Ticket submitted successfully.', 
      data: created 
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets', upload.single('photo'), handleCreateTicket);
app.post('/api/complaints', upload.single('photo'), handleCreateTicket);

// 8. Assign Ticket to Technician
const handleAssignTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const { techId, assignedTechnicianId, note } = req.body;
    const targetTech = techId || assignedTechnicianId;
    if (!targetTech) {
      return res.status(400).json({ success: false, message: 'Technician ID is required.' });
    }
    const updated = store.assignComplaint(id, targetTech, note);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket or technician not found.' });
    }
    res.json({ success: true, message: 'Assigned successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/assign', auth.requireRoles('admin'), handleAssignTicket);
app.post('/api/complaints/:ticketId/assign', auth.requireRoles('admin'), handleAssignTicket);

// 9. Update Ticket Status or Attributes (Admin / Dispatcher)
const handleUpdateTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const updated = store.updateComplaint(id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Updated successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.patch('/api/tickets/:id', auth.requireRoles('admin', 'technician'), handleUpdateTicket);
app.patch('/api/complaints/:ticketId', auth.requireRoles('admin', 'technician'), handleUpdateTicket);

// 10. Technician Resolve Endpoint (with after-repair photo)
const handleResolveTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const updates = {
      status: 'Resolved',
      repairNotes: req.body.repairNotes || 'Repaired fixture and validated illumination.',
      updatedBy: req.body.technicianName || 'Field Technician'
    };
    if (req.file) {
      updates.resolutionPhoto = `/uploads/${req.file.filename}`;
    }
    const resolved = store.updateComplaint(id, updates);
    if (!resolved) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Issue resolved successfully.', data: resolved });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/resolve', auth.requireRoles('admin', 'technician'), upload.single('resolutionPhoto'), handleResolveTicket);
app.post('/api/complaints/:ticketId/resolve', auth.requireRoles('admin', 'technician'), upload.single('resolutionPhoto'), handleResolveTicket);

// 11. IoT Fault Telemetry Simulator
app.post('/api/iot/simulate', auth.requireRoles('admin'), (req, res) => {
  try {
    const { poleCode, faultType, urgencyLevel, priority } = req.body;
    const poles = store.getPoles();
    const targetPole = poles.find(p => p.code === poleCode || p.id === poleCode) || poles[Math.floor(Math.random() * poles.length)];

    const faultDescriptions = {
      "Completely Off": "IoT Telemetry Alert: Sensor registered 0.0A current draw while circuit is energized. Probable LED driver or diode array burnout.",
      "Flickering": "IoT Stability Alert: Rapid voltage fluctuations (160V - 280V) recorded across driver terminals. Light strobe effect detected.",
      "Day-Burning": "IoT Energy Waste Alert: Photocell sensor stuck closed. Pole remains powered during broad daylight (12:30 PM).",
      "Wire Hazard": "IoT Security Alert: Tamper switch triggered on pole base access cover. Potential wire theft or vehicle collision."
    };

    const chosenFault = faultType || "Completely Off";
    const chosenUrgency = urgencyLevel || priority || (chosenFault === "Wire Hazard" ? "Emergency Hazard" : "High Priority");

    const ticketData = {
      poleId: targetPole.id,
      poleCode: targetPole.code,
      issueType: chosenFault,
      urgencyLevel: chosenUrgency,
      description: faultDescriptions[chosenFault] || "Automated sensor fault detection triggered.",
      address: targetPole.street,
      wardZone: targetPole.ward,
      location: {
        type: "Point",
        coordinates: [targetPole.lng, targetPole.lat]
      },
      reporter: {
        fullName: "Automated IoT Telemetry Gateway",
        mobileNumber: "IOT-TELEMETRY"
      },
      source: "IoT Automated Sensor"
    };

    const created = store.createComplaint(ticketData);
    res.status(201).json({
      success: true,
      message: `IoT Fault simulated for pole ${targetPole.code}`,
      data: created
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 12. Export Tickets / Complaints as CSV
app.get('/api/export/csv', auth.requireRoles('admin'), (req, res) => {
  try {
    const complaints = store.getComplaints();
    const headers = [
      'Ticket ID', 'Pole Code', 'Ward / Zone', 'Issue Type', 'Urgency Level', 'Status', 
      'Reporter Name', 'Reporter Phone', 'Longitude', 'Latitude', 'Technician', 'Created At', 'Resolved At'
    ];
    
    const rows = complaints.map(c => [
      `"${c._id || c.ticketId}"`,
      `"${c.poleCode || c.poleId || ''}"`,
      `"${c.wardZone || c.ward || ''}"`,
      `"${c.issueType || ''}"`,
      `"${c.urgencyLevel || c.priority || ''}"`,
      `"${c.status || ''}"`,
      `"${c.reporter?.fullName || c.citizenName || ''}"`,
      `"${c.reporter?.mobileNumber || c.citizenPhone || ''}"`,
      `"${c.location?.coordinates?.[0] ?? c.lng ?? ''}"`,
      `"${c.location?.coordinates?.[1] ?? c.lat ?? ''}"`,
      `"${c.assignedTechnicianId || c.assignedTechId || 'Unassigned'}"`,
      `"${c.createdAt || ''}"`,
      `"${c.resolvedAt || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="streetlight_fault_report.csv"');
    res.status(200).send(csvContent);
  } catch (err) {
    res.status(500).send('Error generating CSV report');
  }
});

// 13. Citizen Feedback Endpoint
const handleFeedback = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const { rating, feedback } = req.body;
    const updated = store.addFeedback(id, rating, feedback);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Feedback recorded successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/feedback', auth.requireAuth, handleFeedback);
app.post('/api/complaints/:ticketId/feedback', auth.requireAuth, handleFeedback);

// 14. Deep Analytics Endpoint
app.get('/api/analytics', auth.requireRoles('admin'), (req, res) => {
  try {
    const analytics = store.getAnalytics();
    res.json({ success: true, data: analytics });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/notifications', (req, res) => {
  try { res.json({ success: true, data: store.getNotifications() }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.post('/api/notifications/read', auth.requireRoles('admin'), (req, res) => {
  try { store.markNotificationsRead(); res.json({ success: true }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});
app.get('/api/reports/monthly', auth.requireRoles('admin'), (req, res) => {
  try { res.json({ success: true, data: store.getMonthlyReport(req.query.month) }); }
  catch (err) { res.status(500).json({ success: false, error: err.message }); }
});

// Fallback to index.html for SPA
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server if not already imported as module
if (require.main === module) {
  auth.bootstrapAdmin().then(() => app.listen(PORT, () => {
      console.log(`Street Light Fault Reporting System running at http://localhost:${PORT}`);
    })).catch(err => { console.error(err.message); process.exit(1); });
}

module.exports = app;
