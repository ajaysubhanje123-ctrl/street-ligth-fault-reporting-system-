@echo off
title Street Light Fault Reporting System Launcher
cd /d "%~dp0"

echo ========================================================
echo Starting Street Light Fault Reporting System (LumiGuard)
echo ========================================================

netstat -ano | findstr /R /C:":3000 " >nul
if %errorlevel% equ 0 (
    echo [OK] Server is already running on http://localhost:3000
) else (
    echo [*] Starting backend server in persistent background window...
    start "LumiGuard Server [DO NOT CLOSE]" cmd /k "title LumiGuard Server ^& cd /d "%~dp0" ^& node server.js"
    timeout /t 2 /nobreak >nul
)

echo [*] Launching application in your web browser...
start "" "http://localhost:3000"

echo.
echo ========================================================
echo System active at: http://localhost:3000
echo - You can freely reload (F5) the browser page at any time.
echo - Keep the server console window open.
echo ========================================================
echo.
timeout /t 5 >nul
exit
