const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const store = require('./data/store');
const TicketModel = require('./models/Ticket');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure upload directory exists
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'yit-photo-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed.'));
    }
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend and uploads
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir));

// Initialize DB
store.initDB();

// ================= API ROUTES =================

// 1. Get Summary Stats
app.get('/api/stats', (req, res) => {
  try {
    const stats = store.getStats();
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Get All Campus Poles
app.get('/api/poles', (req, res) => {
  try {
    const poles = store.getPoles();
    res.json({ success: true, data: poles });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Add a New Campus Pole
app.post('/api/poles', (req, res) => {
  try {
    const newPole = store.addPole(req.body);
    res.status(201).json({ success: true, data: newPole });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Get Maintenance Technicians / Campus Electricians
app.get('/api/technicians', (req, res) => {
  try {
    const technicians = store.getTechnicians();
    res.json({ success: true, data: technicians });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Get Official Campus Locations (The 7 Locations)
app.get('/api/locations', (req, res) => {
  res.json({
    success: true,
    data: TicketModel.CAMPUS_LOCATIONS
  });
});

// ================= TICKET MODEL REST API =================

// 6. Get Tickets / Complaints
const handleGetTickets = (req, res) => {
  try {
    const { status, campusLocation, wardZone, ward, urgencyLevel, priority, search, reporterId, usn } = req.query;
    const tickets = store.getComplaints({ 
      status, 
      campusLocation: campusLocation || wardZone || ward, 
      priority: urgencyLevel || priority, 
      search,
      reporterId: reporterId || usn
    });
    res.json({ success: true, data: tickets, count: tickets.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.get('/api/tickets', handleGetTickets);
app.get('/api/complaints', handleGetTickets);

// 7. Get Ticket by ID or Student USN or Phone
const handleGetTicketById = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const ticket = store.getComplaintByTicket(id);
    if (!ticket) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, data: ticket });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.get('/api/tickets/:id', handleGetTicketById);
app.get('/api/complaints/:ticketId', handleGetTicketById);

// 8. Create New Ticket (Supports multipart photo upload or JSON)
const handleCreateTicket = (req, res) => {
  try {
    const ticketData = { ...req.body };
    if (req.file) {
      ticketData.photoUrl = `/uploads/${req.file.filename}`;
    }

    // Parse coordinates or location if passed as string
    if (typeof ticketData.location === 'string') {
      try { ticketData.location = JSON.parse(ticketData.location); } catch (e) {}
    }
    if (typeof ticketData.reporter === 'string') {
      try { ticketData.reporter = JSON.parse(ticketData.reporter); } catch (e) {}
    }

    const created = store.createComplaint(ticketData);
    res.status(201).json({ 
      success: true, 
      message: 'Campus street light fault ticket submitted successfully.', 
      data: created 
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets', upload.single('photo'), handleCreateTicket);
app.post('/api/complaints', upload.single('photo'), handleCreateTicket);

// 9. Assign Ticket to Technician
const handleAssignTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const { techId, assignedTechnicianId, note } = req.body;
    const targetTech = techId || assignedTechnicianId;
    if (!targetTech) {
      return res.status(400).json({ success: false, message: 'Technician ID is required.' });
    }
    const updated = store.assignComplaint(id, targetTech, note);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket or technician not found.' });
    }
    res.json({ success: true, message: 'Work order dispatched successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/assign', handleAssignTicket);
app.post('/api/complaints/:ticketId/assign', handleAssignTicket);

// 10. Update Ticket Status or Attributes (Admin / Maintenance Supervisor)
const handleUpdateTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const updated = store.updateComplaint(id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Updated successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.patch('/api/tickets/:id', handleUpdateTicket);
app.patch('/api/complaints/:ticketId', handleUpdateTicket);

// 11. Maintenance Electrician Resolve Endpoint (with after-repair photo)
const handleResolveTicket = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const updates = {
      status: 'Resolved',
      repairNotes: req.body.repairNotes || 'Repaired campus fixture and verified illumination.',
      updatedBy: req.body.technicianName || 'Campus Maintenance Electrician'
    };
    if (req.file) {
      updates.resolutionPhoto = `/uploads/${req.file.filename}`;
    }
    const resolved = store.updateComplaint(id, updates);
    if (!resolved) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Campus fault resolved successfully.', data: resolved });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/resolve', upload.single('resolutionPhoto'), handleResolveTicket);
app.post('/api/complaints/:ticketId/resolve', upload.single('resolutionPhoto'), handleResolveTicket);

// 12. Real-time Campus Notifications
app.get('/api/notifications', (req, res) => {
  try {
    const notifications = store.getNotifications();
    res.json({ success: true, data: notifications });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/notifications/read', (req, res) => {
  try {
    store.markNotificationsRead();
    res.json({ success: true, message: 'All notifications marked as read.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 13. Monthly Maintenance Reports
app.get('/api/reports/monthly', (req, res) => {
  try {
    const month = req.query.month; // e.g. '2026-11'
    const report = store.getMonthlyReport(month);
    res.json({ success: true, data: report });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 14. IoT Campus Fault Simulator
app.post('/api/iot/simulate', (req, res) => {
  try {
    const { poleCode, faultType, urgencyLevel, priority } = req.body;
    const poles = store.getPoles();
    const targetPole = poles.find(p => p.code === poleCode || p.id === poleCode) || poles[Math.floor(Math.random() * poles.length)];

    const faultDescriptions = {
      "Completely Off": "IoT Telemetry Alert: Campus sensor registered 0.0A load while circuit breaker is active. Probable LED driver or surge protector burnout.",
      "Flickering": "IoT Stability Alert: Rapid voltage fluctuations (170V - 270V) recorded across driver terminals at " + targetPole.campusLocation + ". Strobe flicker detected.",
      "Day-Burning": "IoT Green Energy Alert: Optical twilight sensor stuck closed. High-wattage fixture remains powered during broad daylight at " + targetPole.campusLocation + ".",
      "Wire Hazard": "IoT Security Alert: Tamper alarm triggered on pole base access cover. Exposed cables detected near pedestrian walkway."
    };

    const chosenFault = faultType || "Completely Off";
    const chosenUrgency = urgencyLevel || priority || (chosenFault === "Wire Hazard" ? "Emergency Hazard" : "High Priority");

    const ticketData = {
      poleId: targetPole.id,
      poleCode: targetPole.code,
      campusLocation: targetPole.campusLocation,
      wardZone: targetPole.campusLocation,
      issueType: chosenFault,
      urgencyLevel: chosenUrgency,
      description: faultDescriptions[chosenFault] || "Automated IoT telemetry gateway sensor fault alert.",
      address: targetPole.street,
      location: {
        type: "Point",
        coordinates: [targetPole.lng, targetPole.lat]
      },
      reporter: {
        fullName: "YIT Automated IoT Sensor Gateway",
        role: "Automated System",
        idNumber: "YIT-IOT-GATEWAY",
        mobileNumber: "IOT-TELEMETRY",
        email: "iot.monitoring@yit.edu.in",
        department: "Estates & Infrastructure Telemetry"
      },
      source: "Campus IoT Sensor"
    };

    const created = store.createComplaint(ticketData);
    res.status(201).json({
      success: true,
      message: `Campus IoT fault simulated for pole ${targetPole.code} at ${targetPole.campusLocation}`,
      data: created
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 15. Export Complaints as CSV
app.get('/api/export/csv', (req, res) => {
  try {
    const complaints = store.getComplaints();
    const headers = [
      'Ticket ID', 'Pole Code', 'Campus Location', 'Address / Landmark', 'Issue Type', 'Urgency Level', 'Status', 
      'Reporter Role', 'Reporter Name', 'USN / ID Number', 'Reporter Phone', 'Reporter Email',
      'Longitude', 'Latitude', 'Assigned Electrician', 'Created At', 'Resolved At'
    ];
    
    const rows = complaints.map(c => [
      `"${c._id || c.ticketId}"`,
      `"${c.poleCode || c.poleId || ''}"`,
      `"${c.campusLocation || c.wardZone || ''}"`,
      `"${(c.address || '').replace(/"/g, '""')}"`,
      `"${c.issueType || ''}"`,
      `"${c.urgencyLevel || c.priority || ''}"`,
      `"${c.status || ''}"`,
      `"${c.reporter?.role || 'Student'}"`,
      `"${c.reporter?.fullName || c.citizenName || ''}"`,
      `"${c.reporter?.idNumber || ''}"`,
      `"${c.reporter?.mobileNumber || c.citizenPhone || ''}"`,
      `"${c.reporter?.email || ''}"`,
      `"${c.location?.coordinates?.[0] ?? c.lng ?? ''}"`,
      `"${c.location?.coordinates?.[1] ?? c.lat ?? ''}"`,
      `"${c.assignedTechName || c.assignedTechnicianId || 'Unassigned'}"`,
      `"${c.createdAt || ''}"`,
      `"${c.resolvedAt || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="YIT_Streetlight_Fault_Report.csv"');
    res.status(200).send(csvContent);
  } catch (err) {
    res.status(500).send('Error generating CSV report');
  }
});

// 16. Reporter Feedback Endpoint
const handleFeedback = (req, res) => {
  try {
    const id = req.params.id || req.params.ticketId;
    const { rating, feedback } = req.body;
    const updated = store.addFeedback(id, rating, feedback);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }
    res.json({ success: true, message: 'Feedback recorded successfully.', data: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
app.post('/api/tickets/:id/feedback', handleFeedback);
app.post('/api/complaints/:ticketId/feedback', handleFeedback);

// 17. Campus Analytics Endpoint
app.get('/api/analytics', (req, res) => {
  try {
    const analytics = store.getAnalytics();
    res.json({ success: true, data: analytics });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Fallback to index.html for SPA
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server if not already imported as module
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`Yenepoya Institute of Technology (YIT) Moodbidri`);
    console.log(`Campus Street Light Fault Reporting & Maintenance System`);
    console.log(`URL: http://localhost:${PORT}`);
    console.log(`====================================================`);
  });
}

module.exports = app;
