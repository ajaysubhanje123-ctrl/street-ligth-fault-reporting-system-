const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const sessions = new Map();
const SESSION_MS = 8 * 60 * 60 * 1000;
const normalizeEmail = email => String(email || '').trim().toLowerCase();

function readUsers() {
  try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return []; throw error; }
}
function writeUsers(users) {
  const temp = `${USERS_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(users, null, 2), { mode: 0o600 });
  fs.renameSync(temp, USERS_FILE);
}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (err, key) =>
    err ? reject(err) : resolve({ salt, hash: key.toString('hex') })));
}
function comparePassword(password, user) {
  return new Promise((resolve, reject) => crypto.scrypt(password, user.salt, 64, (err, key) => {
    if (err) return reject(err);
    const stored = Buffer.from(user.passwordHash, 'hex');
    resolve(stored.length === key.length && crypto.timingSafeEqual(stored, key));
  }));
}
function publicUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role, idNumber: user.idNumber || '', department: user.department || '' };
}
async function bootstrapAdmin() {
  const email = normalizeEmail(process.env.ADMIN_EMAIL);
  const password = process.env.ADMIN_PASSWORD;
  if (!email && !password) return;
  if (!email || !password || password.length < 12) throw new Error('Set both ADMIN_EMAIL and ADMIN_PASSWORD (at least 12 characters) to provision an administrator.');
  const users = readUsers();
  const existing = users.find(user => user.role === 'admin');
  if (existing) return;
  const credentials = await hashPassword(password);
  users.push({ ...credentials, id: crypto.randomUUID(), name: process.env.ADMIN_NAME || 'System Administrator', email, role: 'admin', createdAt: new Date().toISOString() });
  writeUsers(users);
  console.log(`Administrator account provisioned for ${email}.`);
}
function createSession(user) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { user: publicUser(user), expiresAt: Date.now() + SESSION_MS });
  return token;
}
function sessionMiddleware(req, res, next) {
  const token = (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('sl_session='))?.slice('sl_session='.length);
  const session = token && sessions.get(token);
  if (session && session.expiresAt > Date.now()) req.user = session.user;
  else if (token) sessions.delete(token);
  next();
}
function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ success: false, message: 'Sign in is required.' });
  next();
}
function requireRoles(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, message: 'Sign in is required.' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ success: false, message: 'Your account does not have access to this action.' });
    next();
  };
}
function setSessionCookie(res, token, secure) {
  res.setHeader('Set-Cookie', `sl_session=${token}; HttpOnly; Path=/; SameSite=Strict; Max-Age=${SESSION_MS / 1000}${secure ? '; Secure' : ''}`);
}
function clearSessionCookie(res, secure) {
  res.setHeader('Set-Cookie', `sl_session=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0${secure ? '; Secure' : ''}`);
}
async function register({ name, email, password, idNumber, department }) {
  email = normalizeEmail(email);
  if (!name || name.trim().length < 2 || !/^\S+@\S+\.\S+$/.test(email) || !password || password.length < 10) {
    const error = new Error('Provide a name, valid email, and password with at least 10 characters.'); error.status = 400; throw error;
  }
  const users = readUsers();
  if (users.some(user => user.email === email)) { const error = new Error('An account already exists for this email.'); error.status = 409; throw error; }
  const credentials = await hashPassword(password);
  const user = { ...credentials, id: crypto.randomUUID(), name: name.trim(), email, idNumber: String(idNumber || '').trim(), department: String(department || '').trim(), role: 'user', createdAt: new Date().toISOString() };
  users.push(user); writeUsers(users); return user;
}
async function createManagedUser({ name, email, password, role, idNumber, department }) {
  if (!['user', 'technician', 'admin'].includes(role)) { const error = new Error('Role must be user, technician, or admin.'); error.status = 400; throw error; }
  const user = await register({ name, email, password, idNumber, department });
  const users = readUsers();
  const saved = users.find(item => item.id === user.id);
  saved.role = role; writeUsers(users); return saved;
}
function listUsers() { return readUsers().map(publicUser); }
async function login(email, password) {
  const user = readUsers().find(item => item.email === normalizeEmail(email));
  if (!user || !(await comparePassword(String(password || ''), user))) { const error = new Error('Email or password is incorrect.'); error.status = 401; throw error; }
  return user;
}
function revokeSession(req) {
  const token = (req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('sl_session='))?.slice('sl_session='.length);
  if (token) sessions.delete(token);
}

module.exports = { bootstrapAdmin, sessionMiddleware, requireAuth, requireRoles, createSession, setSessionCookie, clearSessionCookie, register, createManagedUser, listUsers, login, revokeSession, publicUser };
