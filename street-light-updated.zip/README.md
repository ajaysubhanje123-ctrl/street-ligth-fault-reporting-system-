# LumiGuard: Smart Street Light Fault Reporting & Maintenance System

A full-stack, smart city municipal web application for automated streetlight fault detection, citizen grievance reporting, field technician work orders, and real-time GIS grid telemetry.

---

## 🌟 Key Features

### 1. 📢 Citizen Grievance Reporting Portal
- **GPS Location Detection:** Auto-detect coordinates using device HTML5 Geolocation or pick location directly on an interactive Leaflet map.
- **Smart Pole Matching:** Automatically identifies the nearest street light pole within the vicinity and pre-fills its Ward, Pole Code, and Street Address.
- **Fault Categorization:** 
  - 🌑 Complete Blackout / Bulb Off
  - ⚡ Flickering / Strobe Effect
  - ☀️ Day-Burning (Energy Waste)
  - ⚠️ Exposed Wiring / Electrical Shock Hazard
  - 💥 Broken Fixture / Physical Damage
  - 💡 Dim / Low Illumination
- **Photo Upload:** Upload or take real-time photos of damaged fixtures (supports up to 10MB JPEG, PNG, WEBP).
- **Instant Digital Ticket & QR Code Receipt:** Generates a unique tracking reference (e.g., `SL-2026-4821`) and an instant scannable smartphone QR code.

### 2. 🔍 Real-Time Complaint Tracking & Lifecycle
- Search by **Ticket ID** or **Citizen Mobile Number**.
- **5-Stage Visual Workflow Timeline:**
  1. `Reported` &rarr; Complaint registered in municipal database
  2. `Under Review` &rarr; Priority and electrical safety hazard evaluated
  3. `Technician Assigned` &rarr; Work order dispatched with technician contact info
  4. `In Progress` &rarr; Field technician arrived on-site
  5. `Resolved` &rarr; Restored & verified with resolution remarks & proof photo
- Full historical audit trail with timestamps.

### 3. 🗺️ Live GIS Street Light Grid Map
- Real-time dark mode CartoDB / OpenStreetMap canvas.
- Glowing color-coded status pins:
  - 🟢 **Operational** (Steady green glow)
  - 🔴 **Active Fault / Dark** (Pulsing emergency red glow)
  - 🟡 **Under Repair** (Amber maintenance glow)
- Interactive popups showing Pole Code, Wattage, Circuit ID, Ward, and an instant **"Report Issue For This Pole"** action.

### 4. 🛠️ Field Technician Mobile Workdesk
- Mobile-friendly interface designed for electricians and field crew.
- View assigned repair tickets by ward.
- **Direct 1-Click GPS Navigation** (opens Google Maps route directions to pole coordinates).
- Status updater: Move tickets from `Assigned` &rarr; `In Progress` &rarr; `Resolved`.
- Upload after-repair proof photo and record replaced spare parts.

### 5. 🏛️ Municipality Admin Management Console
- Executive KPI dashboard: Total Poles, Active Faults, Critical Hazards, Restored Total, SLA Resolution Time.
- Master Complaints Filter (search by keywords, filter by Ward, Status, and Priority).
- Work order dispatcher: Assign field electricians to open complaints.
- Register new street light poles to the city grid.
- **1-Click CSV Report Export** for engineering audits.

### 6. ⚡ Automated IoT Smart Grid Telemetry Simulator
- Simulates hardware sensors (LDR photocells, current transformers, voltage monitors) sending telemetry packets:
  - *Zero Current Detection (LED Burnout)*
  - *Daytime Burning (Optical Sensor Failure)*
  - *Voltage Fluctuation / Surge*
  - *Tamper Switch / Live Exposed Cable*
- Automatically triggers grievance tickets and updates the city grid live!

---

## 🚀 How to Run the Application

This package is the Yenepoya Institute of Technology (YIT) Moodbidri campus demo. It uses sample campus records and a local JSON file store.

### Prerequisites
- Node.js (v18 or higher)

### Starting the Server
Open PowerShell or your terminal in this project directory. Install the dependencies once if they are not present:
```powershell
npm install
npm start
```

### Accessing the Web App
Open your web browser and navigate to:
```
http://localhost:3000
```

---

## 📁 Project Structure

```
street light/
├── data/
│   ├── db.json          # Persistent JSON database (poles, complaints, technicians)
│   └── store.js         # Atomic data access & status management layer
├── public/
│   ├── index.html       # Single-Page Application (Citizen, Track, Map, Tech, Admin)
│   ├── css/
│   │   └── style.css    # Modern custom CSS, glow animations & Leaflet styling
│   └── js/
│       └── app.js       # Frontend engine: Leaflet maps, QR code, REST API handlers
├── uploads/             # Stores uploaded fault and repair proof photos
├── server.js            # Express 5 server, sessions, and REST API
├── auth.js              # Account registration, password hashing, and role checks
├── package.json         # Dependencies (express, cors, multer)
├── data/users.json      # Created at runtime for account hashes and roles
└── README.md            # Documentation and instructions
```

---

## 🔌 REST API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/stats` | Summary statistics (uptime %, fault count, avg hours) |
| `GET` | `/api/poles` | Get all monitored street light poles |
| `POST` | `/api/poles` | Register a new street light pole |
| `GET` | `/api/technicians` | List available municipal electricians |
| `GET` | `/api/complaints` | Filter complaints by status, ward, priority, search |
| `GET` | `/api/complaints/:ticketId` | Fetch complaint details and historical timeline |
| `POST` | `/api/complaints` | File a new complaint (supports photo upload) |
| `POST` | `/api/complaints/:ticketId/assign` | Assign ticket to a field technician |
| `PATCH` | `/api/complaints/:ticketId` | Update complaint status and notes |
| `POST` | `/api/complaints/:ticketId/resolve` | Mark ticket resolved with after-repair photo |
| `POST` | `/api/iot/simulate` | Transmit simulated IoT sensor failure packet |
| `GET` | `/api/export/csv` | Download full complaints report as CSV |

## Account access

- **Public visitor:** may view the campus map and submit a fault report.
- **User account:** may sign in and view their own submitted ticket details. New registrations always receive the `user` role.
- **Technician:** may view maintenance tickets and update repair work.
- **Administrator:** may assign tickets, manage poles and accounts, use IoT simulation, and view/export reports.

Passwords are stored as salted scrypt hashes. Sign-in uses an HTTP-only, same-site session cookie; sessions expire after eight hours and are invalidated when the server restarts. User records are stored in `data/users.json` and should be backed up with the project data.

### Provision the first administrator

In PowerShell, set credentials in the server process environment before starting it. Use a unique password of at least 12 characters and keep it private:

```powershell
$env:ADMIN_EMAIL = 'admin@your-domain.example'
$env:ADMIN_PASSWORD = 'your-private-password-at-least-12-characters'
$env:ADMIN_NAME = 'Campus Administrator'
npm start
```

The server creates the first administrator account on its first start. The password is hashed and is not saved in the project configuration. Once an administrator already exists, changing these environment values does not replace that account.

Administrators can create user, technician, or additional administrator accounts through `POST /api/auth/users` while signed in. Public account registration cannot choose an elevated role. Do not expose the demo server to the internet without adding production-grade deployment controls and a production database.

## Project review notes

The archive contains a second, separate `backend/` app in addition to the root app. The launcher and README run the root `server.js`; the root frontend also calls monthly report and notifications endpoints, which were missing in the archive. The root app now serves those endpoints. Some claims in the original report (such as automated real-world IoT telemetry and a city GIS service) describe planned or simulated functions; the packaged data and IoT page are a campus demo, not a live municipal deployment.
