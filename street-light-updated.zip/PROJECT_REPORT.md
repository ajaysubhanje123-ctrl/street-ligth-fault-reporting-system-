# Street Light Fault Reporting & Smart Maintenance System (LumiGuard)
## Project Synopsis & Presentation Report

---

### 1. Project Title & Abstract
**Title:** Smart Street Light Fault Reporting and Maintenance Management System (LumiGuard)  
**Abstract:**  
Street lighting is vital urban infrastructure for pedestrian safety, vehicular traffic, and crime prevention. However, traditional municipal maintenance depends on delayed manual citizen phone calls or periodic visual patrols. **LumiGuard** resolves this through a comprehensive, full-stack digital solution combining:
1. Citizen Geo-Reporting Portal with automated GPS pole-matching and image proof upload.
2. Real-time GIS interactive map displaying color-coded grid health (Active, Faulty, In-Repair).
3. Automated IoT sensor fault telemetry (LDR photocell failure, zero-current bulb burnout, voltage surge).
4. Field technician dispatch system with turn-by-turn navigation and verified resolution logs.

---

### 2. Problem Statement
- **Delayed Fault Detection:** Bulbs stay out for days/weeks before municipal discovery.
- **Daytime Burning Waste:** Faulty photocells leave lights ON in bright daylight, wasting city electricity.
- **Lack of Transparency:** Citizens have no mechanism to track if their complaint was acted upon.
- **Inefficient Field Logistics:** Electricians lack exact pole GPS coordinates and spare part requirements before dispatch.

---

### 3. System Architecture & Workflows

```
   [Citizen Mobile / Web]               [Automated IoT Telemetry]
     (GPS & Photo Upload)             (LDR & Current Sensor Alert)
              │                                    │
              └──────────────────┬─────────────────┘
                                 │
                                 ▼
                     [Express 5 REST API Backend]
                                 │
                   ┌─────────────┴─────────────┐
                   ▼                           ▼
          [Data Store (db.json)]      [GIS Grid Telemetry]
                   │
         ┌─────────┴─────────┐
         ▼                   ▼
[Admin Dashboard]     [Technician Workdesk]
(Dispatch & Reports)  (GPS Route & Repair Proof)
```

---

### 4. Key Functional Modules

| Module | Features |
|---|---|
| **Citizen Portal** | GPS location detection, pole selector, photo upload, 6 fault categories, urgency rating, instant QR code & ticket generation (`SL-2026-XXXX`). |
| **Grievance Tracker** | Real-time 5-stage progress lifecycle (Reported &rarr; Under Review &rarr; Assigned &rarr; In Progress &rarr; Resolved), audit trail. |
| **Live GIS Grid Map** | Leaflet.js interactive dark-mode map, real-time glowing markers (🟢 Green, 🔴 Red pulsing, 🟡 Amber), 1-click pole reporting. |
| **Field Tech Desk** | Work order queue, 1-click Google Maps GPS route navigation, "Start Work" and "Resolve Ticket" with resolution remarks & proof photo. |
| **Admin Console** | Key performance indicators (Uptime %, avg response hours), technician dispatcher, pole registry, 1-click CSV export. |
| **IoT Simulator** | Interactive testing for LED burnout, daytime burning energy waste, voltage fluctuations, and wire tamper alerts. |

---

### 5. Technology Stack

- **Runtime & Backend:** Node.js (v20), Express.js (v5)
- **Frontend:** Responsive HTML5, Tailwind CSS, Leaflet.js (GIS Mapping), QRCode.js, FontAwesome 6
- **Database:** Atomic persistent JSON database (`store.js` + `db.json`)
- **File Uploads:** Multer multipart engine (stores in `/uploads`)
- **APIs:** RESTful architecture with CORS enabled

---

### 6. Frequently Asked Questions (Viva / Defense Prep)

**Q1: How does the system handle duplicate complaints for the same pole?**  
*Answer:* The system tags complaints by unique `poleId` and `circuitId`. On the live GIS map, a pole already flagged as faulty shows its active status, preventing redundant dispatches.

**Q2: How does the IoT simulation represent real-world sensors?**  
*Answer:* In a physical deployment, an ESP32 or Arduino with an ACS712 current sensor and an LDR (light sensor) transmits MQTT/HTTP packets to `/api/iot/simulate`. If current is 0.0A when the circuit timer is ON, it signals bulb failure automatically.

**Q3: Can field technicians navigate to the exact streetlight?**  
*Answer:* Yes, each pole stores latitude and longitude coordinates. The technician workdesk includes a direct link that opens Google Maps turn-by-turn directions directly to the pole's GPS point.

---

## Implementation status and access model

This archive is a YIT campus prototype backed by sample records in a local JSON store. The IoT simulator creates sample tickets; it is not connected to physical sensor hardware. A separate `backend/` directory is included, but the root `server.js` is the app launched by `start_app.bat`.

The root application now supports server-side user, technician, and administrator roles. Users register as standard users. Administrators are provisioned using `ADMIN_EMAIL` and `ADMIN_PASSWORD` at first startup, and can create elevated accounts through `POST /api/auth/users`. Administrative routes are protected on the server; the browser interface alone cannot grant permissions.
