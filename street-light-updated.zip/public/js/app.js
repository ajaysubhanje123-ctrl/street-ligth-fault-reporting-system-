// Yenepoya Institute of Technology (YIT), Moodbidri
// Campus Street Light Fault Reporting & Maintenance System (YIT SmartLight)
// Frontend Application Engine

let poles = [];
let technicians = [];
let complaints = [];
let stats = {};
let notifications = [];

let pickerMap = null;
let pickerMarker = null;
let pickerPoleMarkers = [];

let liveMap = null;
let liveMapMarkers = [];
let activeMapFilter = 'all';
let activeMapLocation = 'all';

let selectedPhotoFile = null;
let currentTicketModalId = null;
let currentAssignTicketId = null;
let currentResolveTicketId = null;

let soundEnabled = true;
let gridTimeMode = 'night'; // 'night' or 'day'

// YIT Moodbidri Campus Coordinates (Thodar, Moodbidri, Mangalore)
const DEFAULT_LAT = 13.0665;
const DEFAULT_LNG = 74.9953;

// The 7 Official Campus Locations
const CAMPUS_LOCATIONS = [
  'Main College Building',
  'College Entrance',
  'Campus Roads',
  'Parking Area',
  'Hostel Area',
  'Playground',
  'Library Area'
];

// Guests can report faults; account access is checked by the server.
let currentUser = {
  authenticated: false,
  role: 'Student',
  name: 'Guest',
  idNumber: '',
  phone: '',
  email: '',
  department: ''
};

// Web Audio API Synthesizer (Zero external sound files needed)
function playTone(freq, type = 'sine', duration = 0.15, gainVal = 0.08) {
  if (!soundEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(gainVal, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch (e) {}
}

function soundSuccess() {
  playTone(523.25, 'sine', 0.1, 0.06); // C5
  setTimeout(() => playTone(659.25, 'sine', 0.12, 0.06), 100); // E5
  setTimeout(() => playTone(783.99, 'sine', 0.25, 0.08), 220); // G5
}

function soundAlert() {
  playTone(880, 'sawtooth', 0.15, 0.08);
  setTimeout(() => playTone(880, 'sawtooth', 0.25, 0.08), 200);
}

function soundClick() {
  playTone(440, 'triangle', 0.06, 0.03);
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  const icon = document.getElementById('sound-icon');
  if (icon) {
    icon.className = soundEnabled ? 'fa-solid fa-volume-high text-sky-400' : 'fa-solid fa-volume-xmark text-slate-500';
  }
  showToast(soundEnabled ? 'Sound FX Enabled' : 'Sound FX Muted', 'info');
}

function toggleGridTimeMode() {
  gridTimeMode = gridTimeMode === 'night' ? 'day' : 'night';
  const icon = document.getElementById('time-icon');
  const text = document.getElementById('time-text');
  if (gridTimeMode === 'day') {
    if (icon) icon.className = 'fa-solid fa-sun text-yellow-400';
    if (text) text.innerText = 'Day';
    showToast('Campus Simulation: Daytime Mode (Day-burning waste highlighted)', 'info');
  } else {
    if (icon) icon.className = 'fa-solid fa-moon text-indigo-400';
    if (text) text.innerText = 'Night';
    showToast('Campus Simulation: Night Mode (Walkway illumination active)', 'info');
  }
  renderLiveMapMarkers();
}

// Simulated SMS & Campus Email notification banner
function simulateSMS(phone, text) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const sms = document.createElement('div');
  sms.className = 'p-3.5 rounded-2xl border border-sky-400/50 bg-navy-900/95 backdrop-blur-md shadow-2xl text-xs flex items-start gap-3 transition-all transform translate-y-2 opacity-0 max-w-sm pointer-events-auto border-l-4 border-l-sky-400';
  sms.innerHTML = `
    <div class="w-8 h-8 rounded-full bg-blue-600/30 text-sky-300 flex items-center justify-center shrink-0 text-sm">
      <i class="fa-solid fa-comment-sms"></i>
    </div>
    <div class="flex-1">
      <div class="flex items-center justify-between mb-0.5">
        <strong class="text-sky-300 font-bold">SMS to ${escapeHtml(phone)}</strong>
        <span class="text-[9px] text-slate-400">YIT Estates Alert</span>
      </div>
      <p class="text-slate-200 text-[11px] leading-relaxed">${escapeHtml(text)}</p>
    </div>
    <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white text-xs">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;
  container.appendChild(sms);

  requestAnimationFrame(() => {
    sms.classList.remove('translate-y-2', 'opacity-0');
  });

  setTimeout(() => {
    if (sms.parentNode) {
      sms.classList.add('opacity-0', 'translate-x-4');
      setTimeout(() => sms.remove(), 300);
    }
  }, 7000);
}

// Toast notification helper
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const colors = {
    success: 'border-emerald-500/40 bg-navy-900 text-emerald-300 border-l-4 border-l-emerald-500',
    error: 'border-rose-500/40 bg-navy-900 text-rose-300 border-l-4 border-l-rose-500',
    warning: 'border-amber-500/40 bg-navy-900 text-amber-300 border-l-4 border-l-amber-500',
    info: 'border-blue-500/40 bg-navy-900 text-sky-300 border-l-4 border-l-blue-500'
  };
  const icons = {
    success: 'fa-solid fa-circle-check text-emerald-400',
    error: 'fa-solid fa-circle-xmark text-rose-400',
    warning: 'fa-solid fa-triangle-exclamation text-amber-400',
    info: 'fa-solid fa-circle-info text-sky-400'
  };

  toast.className = `p-3 rounded-xl border shadow-xl text-xs flex items-center gap-2.5 transition-all transform translate-y-2 opacity-0 pointer-events-auto ${colors[type] || colors.info}`;
  toast.innerHTML = `
    <i class="${icons[type] || icons.info} text-sm"></i>
    <span class="font-medium flex-1">${escapeHtml(message)}</span>
    <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-white text-xs ml-1">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;
  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.remove('translate-y-2', 'opacity-0');
  });

  setTimeout(() => {
    if (toast.parentNode) {
      toast.classList.add('opacity-0', 'translate-x-4');
      setTimeout(() => toast.remove(), 300);
    }
  }, 4500);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ================= VIEW SWITCHER =================
function switchView(viewName) {
  soundClick();
  if (viewName === 'admin' && !['admin', 'technician'].includes(currentUser.accessRole)) {
    openLoginModal(); showToast('Maintenance access requires an authorized account.', 'warning'); return;
  }
  if (viewName === 'reports' && currentUser.accessRole !== 'admin') {
    openLoginModal(); showToast('Reports are for administrators.', 'warning'); return;
  }
  if (viewName === 'my-complaints' && (!currentUser.authenticated || currentUser.accessRole !== 'user')) {
    openLoginModal(); showToast('Sign in to see your complaints.', 'warning'); return;
  }
  const views = ['report', 'track', 'map', 'admin', 'reports', 'my-complaints'];
  
  views.forEach(v => {
    const el = document.getElementById(`view-${v}`);
    const navBtn = document.getElementById(`nav-btn-${v}`);
    if (el) {
      if (v === viewName) {
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    }
    if (navBtn) {
      if (v === viewName) {
        navBtn.className = 'nav-tab-btn px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center space-x-2 text-white bg-blue-600/30 text-sky-300 border border-blue-500/40 shadow-sm';
      } else {
        navBtn.className = 'nav-tab-btn px-3.5 py-2 rounded-lg text-xs font-bold transition flex items-center space-x-2 text-slate-300 hover:text-white hover:bg-navy-800';
      }
    }
  });

  // Update mobile buttons
  document.querySelectorAll('.mobile-nav-btn').forEach(btn => {
    const fn = btn.getAttribute('onclick') || '';
    if (fn.includes(`'${viewName}'`)) {
      btn.className = 'mobile-nav-btn flex flex-col items-center text-[10px] text-sky-400 font-bold py-1';
    } else {
      btn.className = 'mobile-nav-btn flex flex-col items-center text-[10px] text-slate-400 py-1';
    }
  });

  // Re-size maps when shown
  if (viewName === 'report' && pickerMap) {
    setTimeout(() => pickerMap.invalidateSize(), 200);
  }
  if (viewName === 'map') {
    initLiveMap();
    setTimeout(() => {
      if (liveMap) liveMap.invalidateSize();
    }, 200);
  }
  if (viewName === 'admin') {
    loadAdminComplaints();
    loadAnalytics();
  }
  if (viewName === 'reports') {
    loadMonthlyReport();
  }
  if (viewName === 'my-complaints') {
    renderMyComplaints();
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ================= USER LOGIN & AUTHENTICATION =================
let accountMode = 'login';
function openLoginModal() {
  soundClick();
  const modal = document.getElementById('modal-login');
  if (modal) modal.classList.remove('hidden');
  const isSignedIn = currentUser.authenticated;
  document.getElementById('account-logout')?.classList.toggle('hidden', !isSignedIn);
  document.getElementById('account-form')?.classList.toggle('hidden', isSignedIn);
  document.getElementById('account-mode-toggle')?.classList.toggle('hidden', isSignedIn);
}
function closeLoginModal() { document.getElementById('modal-login')?.classList.add('hidden'); }
function toggleAccountMode() {
  accountMode = accountMode === 'login' ? 'register' : 'login';
  const registering = accountMode === 'register';
  document.getElementById('register-name-wrap')?.classList.toggle('hidden', !registering);
  document.getElementById('register-profile')?.classList.toggle('hidden', !registering);
  document.getElementById('account-name').required = registering;
  document.getElementById('account-password').minLength = registering ? 10 : 1;
  document.getElementById('account-password').autocomplete = registering ? 'new-password' : 'current-password';
  document.getElementById('password-help').innerText = registering ? 'Use at least 10 characters.' : 'Use your account password.';
  document.getElementById('account-submit').innerText = registering ? 'Create account' : 'Sign in';
  document.getElementById('account-mode-toggle').innerText = registering ? 'Already have an account? Sign in' : 'Create a standard user account';
}
async function submitAccount(event) {
  event.preventDefault();
  const registering = accountMode === 'register';
  const body = { email: document.getElementById('account-email').value, password: document.getElementById('account-password').value };
  if (registering) Object.assign(body, { name: document.getElementById('account-name').value, idNumber: document.getElementById('account-id').value, department: document.getElementById('account-department').value });
  try {
    const response = await fetch(`/api/auth/${registering ? 'register' : 'login'}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || 'Account request failed.');
    setCurrentUser(result.data); closeLoginModal(); showToast(`Signed in as ${currentUser.role}.`, 'success');
  } catch (error) { showToast(error.message, 'error'); }
}
function setCurrentUser(user) {
  if (!user) return;
  currentUser = { authenticated: true, accessRole: user.role, role: user.role === 'user' ? 'Student' : user.role, name: user.name, idNumber: user.idNumber || '', phone: '', email: user.email, department: user.department || '' };
  applyUserSession();
  const profile = document.getElementById('user-profile-text');
  if (profile) profile.innerText = `${currentUser.name.split(' ')[0]} (${user.role})`;
  document.getElementById('user-profile-icon').className = user.role === 'admin' ? 'fa-solid fa-user-shield' : user.role === 'technician' ? 'fa-solid fa-screwdriver-wrench' : 'fa-solid fa-user';
}
async function logoutAccount() {
  await fetch('/api/auth/logout', { method: 'POST' });
  currentUser = { authenticated: false, accessRole: null, role: 'Student', name: 'Guest', idNumber: '', phone: '', email: '', department: '' };
  document.getElementById('user-profile-text').innerText = 'Sign in';
  closeLoginModal(); applyUserSession(); showToast('Signed out.', 'info');
}
async function loadCurrentUser() {
  try { const response = await fetch('/api/auth/me'); const result = await response.json(); if (result.data) setCurrentUser(result.data); }
  catch (error) { console.warn('Could not restore sign-in state.'); }
}
function loginAsDemoUser() { showToast('Demo profiles were removed. Create an account or sign in.', 'info'); }
function submitCustomLogin(event) { return submitAccount(event); }

function applyUserSession() {
  // Update header button
  const text = document.getElementById('user-profile-text');
  const icon = document.getElementById('user-profile-icon');
  if (text) {
    text.innerText = currentUser.name.split(' ')[0] + (currentUser.idNumber ? ` (${currentUser.idNumber})` : '');
  }
  if (icon) {
    icon.className = currentUser.role === 'Student' ? 'fa-solid fa-user-graduate' : 'fa-solid fa-chalkboard-user';
  }

  // Pre-fill report form
  const nameInput = document.getElementById('citizen-name');
  const idInput = document.getElementById('reporter-id');
  const phoneInput = document.getElementById('citizen-phone');
  const deptInput = document.getElementById('reporter-dept');
  const roleStudent = document.getElementById('role-student');
  const roleStaff = document.getElementById('role-staff');

  if (nameInput) nameInput.value = currentUser.name;
  if (idInput) idInput.value = currentUser.idNumber;
  if (phoneInput) phoneInput.value = currentUser.phone;
  if (deptInput && currentUser.department) deptInput.value = currentUser.department;

  if (currentUser.role === 'Student') {
    if (roleStudent) roleStudent.checked = true;
    handleRoleChange('Student');
  } else {
    if (roleStaff) roleStaff.checked = true;
    handleRoleChange('Staff/Faculty');
  }

  // Update My Complaints
  renderMyComplaints();
}

function handleRoleChange(role) {
  const idLabel = document.getElementById('id-label');
  const idInput = document.getElementById('reporter-id');
  if (role === 'Student') {
    if (idLabel) idLabel.innerHTML = 'Student USN <span class="text-rose-400">*</span>';
    if (idInput) idInput.placeholder = 'e.g. DEMO-STUDENT-01';
  } else {
    if (idLabel) idLabel.innerHTML = 'Staff / Faculty ID <span class="text-rose-400">*</span>';
    if (idInput) idInput.placeholder = 'e.g. YIT-FAC-102';
  }
}

// ================= NOTIFICATIONS ENGINE =================
async function loadNotifications() {
  try {
    const res = await fetch('/api/notifications');
    const json = await res.json();
    if (json.success) {
      notifications = json.data || [];
      renderNotifications();
    }
  } catch (err) {
    console.error('Failed to load notifications:', err);
  }
}

function renderNotifications() {
  const listEl = document.getElementById('notifications-list');
  const badgeEl = document.getElementById('notif-badge');
  if (!listEl) return;

  const unreadCount = notifications.filter(n => !n.read).length;
  if (badgeEl) {
    badgeEl.innerText = unreadCount;
    badgeEl.style.display = unreadCount > 0 ? 'flex' : 'none';
  }

  if (notifications.length === 0) {
    listEl.innerHTML = `<div class="p-3 text-center text-slate-400 text-xs">No active alerts.</div>`;
    return;
  }

  listEl.innerHTML = notifications.map(n => {
    let icon = 'fa-solid fa-bell text-sky-400';
    if (n.category === 'hazard') icon = 'fa-solid fa-triangle-exclamation text-rose-500';
    if (n.category === 'resolved') icon = 'fa-solid fa-circle-check text-emerald-400';
    if (n.category === 'assignment') icon = 'fa-solid fa-user-check text-sky-400';

    const timeAgo = getTimeAgo(new Date(n.time));

    return `
      <div class="p-2.5 rounded-xl border ${n.read ? 'border-blue-950 bg-navy-950/40 text-slate-300' : 'border-blue-800/60 bg-blue-950/30 text-white font-medium'} flex items-start gap-2.5 hover:border-blue-700 transition">
        <i class="${icon} text-sm mt-0.5 shrink-0"></i>
        <div class="flex-1">
          <div class="flex items-center justify-between">
            <strong class="text-xs text-slate-100">${escapeHtml(n.title)}</strong>
            <span class="text-[9px] text-slate-400">${timeAgo}</span>
          </div>
          <p class="text-[11px] text-slate-300 mt-0.5 leading-snug">${escapeHtml(n.message)}</p>
          ${n.ticketId ? `<button onclick="quickTrack('${escapeHtml(n.ticketId)}'); toggleNotificationsPanel();" class="text-[10px] text-sky-400 hover:underline mt-1 inline-block">Track ticket &rarr;</button>` : ''}
        </div>
      </div>
    `;
  }).join('');
}

function toggleNotificationsPanel() {
  const panel = document.getElementById('notifications-panel');
  if (panel) {
    panel.classList.toggle('hidden');
    soundClick();
  }
}

async function markAllNotificationsRead() {
  try {
    await fetch('/api/notifications/read', { method: 'POST' });
    notifications.forEach(n => n.read = true);
    renderNotifications();
    showToast('All notifications marked as read', 'info');
  } catch (err) {
    console.error(err);
  }
}

function getTimeAgo(date) {
  const seconds = Math.floor((new Date() - date) / 1000);
  if (seconds < 60) return 'Just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

// ================= DATA LOADING =================
async function reloadAllData(notify = false) {
  const reloadIcon = document.getElementById('reload-icon');
  if (reloadIcon) reloadIcon.classList.add('animate-spin');

  try {
    const [polesRes, techRes, statsRes, notifRes] = await Promise.all([
      fetch('/api/poles'),
      fetch('/api/technicians'),
      fetch('/api/stats'),
      fetch('/api/notifications')
    ]);

    const polesData = await polesRes.json();
    const techData = await techRes.json();
    const statsData = await statsRes.json();
    const notifData = await notifRes.json();

    if (polesData.success) poles = polesData.data || [];
    if (techData.success) technicians = techData.data || [];
    if (statsData.success) stats = statsData.data || {};
    if (notifData.success) notifications = notifData.data || [];

    // Update UI elements
    updateServerStatus(true);
    renderStats();
    populatePoleDropdowns();
    populateTechnicianDropdowns();
    renderLiveMapMarkers();
    renderNotifications();
    loadAdminComplaints();
    loadAnalytics();

    if (notify) {
      soundSuccess();
      showToast('YIT Campus Grid data synchronized', 'success');
    }
  } catch (err) {
    console.error('Failed to reload campus grid data:', err);
    updateServerStatus(false);
    if (notify) {
      soundAlert();
      showToast('Could not connect to server. Check start_app.bat.', 'error');
    }
  } finally {
    if (reloadIcon) {
      setTimeout(() => reloadIcon.classList.remove('animate-spin'), 600);
    }
  }
}

function updateServerStatus(isOnline) {
  const pill = document.getElementById('server-status-pill');
  const text = document.getElementById('server-status-text');
  const dot = document.getElementById('server-status-dot');
  const banner = document.getElementById('server-offline-banner');

  if (isOnline) {
    if (pill) pill.className = 'hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30';
    if (text) text.innerText = 'YIT Online';
    if (dot) dot.className = 'w-2 h-2 rounded-full bg-emerald-400 animate-pulse';
    if (banner) banner.classList.add('hidden');
  } else {
    if (pill) pill.className = 'hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30';
    if (text) text.innerText = 'Server Offline';
    if (dot) dot.className = 'w-2 h-2 rounded-full bg-rose-500 animate-ping';
    if (banner) banner.classList.remove('hidden');
  }
}

function renderStats() {
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.innerText = val !== undefined ? val : '--';
  };

  setVal('stat-total-poles', stats.totalPoles);
  setVal('stat-pending', stats.pendingCount);
  setVal('stat-hazards', stats.hazardCount);
  setVal('stat-in-progress', stats.inProgressCount);
  setVal('stat-resolved', stats.resolvedCount);
  setVal('stat-avg-hours', stats.avgResolutionHours + 'h');
}

function populatePoleDropdowns() {
  const poleSelect = document.getElementById('pole-select');
  const iotSelect = document.getElementById('iot-pole-select');

  const selectedLoc = document.getElementById('ward-select') ? document.getElementById('ward-select').value : 'Main College Building';

  if (poleSelect) {
    poleSelect.innerHTML = `<option value="">-- Choose Existing Pole (Optional) --</option>` +
      poles
        .filter(p => p.campusLocation === selectedLoc || p.ward === selectedLoc)
        .map(p => `<option value="${p.id}">${escapeHtml(p.code)} - ${escapeHtml(p.street)} (${p.status})</option>`)
        .join('');
  }

  if (iotSelect) {
    iotSelect.innerHTML = poles.map(p => 
      `<option value="${p.code}">${escapeHtml(p.code)} - ${escapeHtml(p.street)} [${p.campusLocation || p.ward}]</option>`
    ).join('');
  }
}

function handleCampusLocationChange() {
  const loc = document.getElementById('ward-select').value;
  populatePoleDropdowns();

  // Auto center picker map to that location if poles exist
  const firstPole = poles.find(p => p.campusLocation === loc || p.ward === loc);
  if (firstPole && pickerMap && pickerMarker) {
    pickerMarker.setLatLng([firstPole.lat, firstPole.lng]);
    pickerMap.setView([firstPole.lat, firstPole.lng], 17);
    updatePickedLocation(firstPole.lat, firstPole.lng);
  }
}

function populateTechnicianDropdowns() {
  const activeTechSelect = document.getElementById('active-technician-select');
  const assignTechSelect = document.getElementById('assign-tech-select');

  const options = technicians.map(t => 
    `<option value="${t.id}">${escapeHtml(t.name)} (${t.designation || 'Electrician'} - ${escapeHtml(t.phone)})</option>`
  ).join('');

  if (activeTechSelect) {
    activeTechSelect.innerHTML = options;
  }
  if (assignTechSelect) {
    assignTechSelect.innerHTML = options;
  }
}

// ================= LOCATION PICKER (LEAFLET) =================
function initPickerMap() {
  if (pickerMap) return;

  const container = document.getElementById('picker-map');
  if (!container) return;

  pickerMap = L.map('picker-map', {
    center: [DEFAULT_LAT, DEFAULT_LNG],
    zoom: 16,
    zoomControl: true
  });

  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    maxZoom: 19
  }).addTo(pickerMap);

  const customIcon = L.divIcon({
    className: 'custom-picker-pin',
    html: `
      <div style="background: #2563eb; width: 34px; height: 34px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(37,99,235,0.6); color: white;">
        <i class="fa-solid fa-lightbulb" style="font-size: 16px;"></i>
      </div>
    `,
    iconSize: [34, 34],
    iconAnchor: [17, 34]
  });

  pickerMarker = L.marker([DEFAULT_LAT, DEFAULT_LNG], {
    draggable: true,
    icon: customIcon
  }).addTo(pickerMap);

  pickerMarker.on('dragend', function (e) {
    const pos = e.target.getLatLng();
    updatePickedLocation(pos.lat, pos.lng);
  });

  pickerMap.on('click', function (e) {
    pickerMarker.setLatLng(e.latlng);
    updatePickedLocation(e.latlng.lat, e.latlng.lng);
  });

  updatePickedLocation(DEFAULT_LAT, DEFAULT_LNG);
}

function updatePickedLocation(lat, lng) {
  const latInput = document.getElementById('lat-input');
  const lngInput = document.getElementById('lng-input');
  if (latInput) latInput.value = lat.toFixed(6);
  if (lngInput) lngInput.value = lng.toFixed(6);

  // Auto-find nearest pole
  let nearestPole = null;
  let minDist = Infinity;
  poles.forEach(p => {
    const d = Math.hypot(p.lat - lat, p.lng - lng);
    if (d < minDist) {
      minDist = d;
      nearestPole = p;
    }
  });

  if (nearestPole && minDist < 0.005) {
    const poleSelect = document.getElementById('pole-select');
    const wardSelect = document.getElementById('ward-select');
    const addrInput = document.getElementById('address-input');

    if (wardSelect && nearestPole.campusLocation) {
      wardSelect.value = nearestPole.campusLocation;
      populatePoleDropdowns();
    }
    if (poleSelect) poleSelect.value = nearestPole.id;
    if (addrInput && !addrInput.value) {
      addrInput.value = nearestPole.street;
    }
  }
}

function detectUserLocation() {
  soundClick();
  const btnText = document.getElementById('loc-btn-text');
  if (btnText) btnText.innerText = 'Detecting GPS...';

  if (!navigator.geolocation) {
    showToast('Geolocation is not supported by your browser.', 'warning');
    if (btnText) btnText.innerText = 'Detect Campus GPS';
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      let lat = pos.coords.latitude;
      let lng = pos.coords.longitude;
      
      // If user is far from Moodbidri campus (e.g. testing off-campus), snap to YIT campus with slight offset
      const distFromYIT = Math.hypot(lat - DEFAULT_LAT, lng - DEFAULT_LNG);
      if (distFromYIT > 0.05) {
        showToast('Detected GPS off-campus. Centering at Yenepoya Institute of Technology.', 'info');
        lat = DEFAULT_LAT;
        lng = DEFAULT_LNG;
      } else {
        showToast('Campus GPS position detected!', 'success');
      }

      pickerMarker.setLatLng([lat, lng]);
      pickerMap.setView([lat, lng], 17);
      updatePickedLocation(lat, lng);
      if (btnText) btnText.innerText = 'Campus GPS Located!';
    },
    (err) => {
      console.warn('Geolocation error:', err);
      pickerMarker.setLatLng([DEFAULT_LAT, DEFAULT_LNG]);
      pickerMap.setView([DEFAULT_LAT, DEFAULT_LNG], 16);
      updatePickedLocation(DEFAULT_LAT, DEFAULT_LNG);
      showToast('Positioned at YIT Moodbidri Central Quad.', 'info');
      if (btnText) btnText.innerText = 'Detect Campus GPS';
    },
    { timeout: 7000, enableHighAccuracy: true }
  );
}

function handlePoleSelectChange() {
  const poleId = document.getElementById('pole-select').value;
  const pole = poles.find(p => p.id === poleId);
  if (pole && pickerMap && pickerMarker) {
    pickerMarker.setLatLng([pole.lat, pole.lng]);
    pickerMap.setView([pole.lat, pole.lng], 17);
    updatePickedLocation(pole.lat, pole.lng);

    const addrInput = document.getElementById('address-input');
    if (addrInput) addrInput.value = pole.street;
  }
}

// ================= LIVE CAMPUS MAP =================
function initLiveMap() {
  if (liveMap) return;

  const container = document.getElementById('live-map');
  if (!container) return;

  liveMap = L.map('live-map', {
    center: [DEFAULT_LAT, DEFAULT_LNG],
    zoom: 16,
    zoomControl: true
  });

  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    maxZoom: 19
  }).addTo(liveMap);

  renderLiveMapMarkers();
}

function renderLiveMapMarkers() {
  if (!liveMap) return;

  liveMapMarkers.forEach(m => liveMap.removeLayer(m));
  liveMapMarkers = [];

  const filteredPoles = poles.filter(p => {
    const matchesStatus = activeMapFilter === 'all' || p.status === activeMapFilter;
    const matchesLoc = activeMapLocation === 'all' || (p.campusLocation === activeMapLocation || p.ward === activeMapLocation);
    return matchesStatus && matchesLoc;
  });

  filteredPoles.forEach(pole => {
    let markerClass = 'pole-marker-active';
    let iconHtml = '<i class="fa-solid fa-lightbulb text-xs"></i>';
    let statusLabel = 'Operational';
    let statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">Operational</span>';

    if (pole.status === 'faulty') {
      markerClass = 'pole-marker-faulty';
      iconHtml = '<i class="fa-solid fa-triangle-exclamation text-xs"></i>';
      statusLabel = 'Faulty / Dark';
      statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300">Active Fault</span>';
    } else if (pole.status === 'in_repair') {
      markerClass = 'pole-marker-repair';
      iconHtml = '<i class="fa-solid fa-screwdriver-wrench text-xs"></i>';
      statusLabel = 'Under Repair';
      statusBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">In Repair</span>';
    }

    const customIcon = L.divIcon({
      className: `custom-pole-marker ${markerClass}`,
      html: iconHtml,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    const marker = L.marker([pole.lat, pole.lng], { icon: customIcon }).addTo(liveMap);

    const popupContent = `
      <div style="min-width: 220px;" class="space-y-2">
        <div class="flex items-center justify-between pb-1 border-b border-blue-900/60">
          <strong class="text-sm font-black text-sky-400 font-mono">${escapeHtml(pole.code)}</strong>
          ${statusBadge}
        </div>
        <div class="text-xs text-slate-200">
          <p class="font-semibold text-white">${escapeHtml(pole.street)}</p>
          <p class="text-[11px] text-sky-300 mt-0.5"><i class="fa-solid fa-building-columns mr-1"></i>${escapeHtml(pole.campusLocation || pole.ward)}</p>
          <div class="grid grid-cols-2 gap-1 text-[10px] text-slate-400 mt-2 bg-navy-950 p-2 rounded-lg border border-blue-900">
            <div>Type: <span class="text-slate-200 font-bold">${escapeHtml(pole.type)}</span></div>
            <div>Wattage: <span class="text-slate-200 font-bold">${pole.wattage}W</span></div>
            <div>Circuit: <span class="text-slate-200 font-bold">${escapeHtml(pole.circuitId || 'YIT-CKT')}</span></div>
            <div>Status: <span class="text-slate-200 font-bold">${statusLabel}</span></div>
          </div>
        </div>
        <button onclick="reportFaultForPole('${escapeHtml(pole.id)}')" class="w-full mt-2 py-1.5 px-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition shadow-md flex items-center justify-center gap-1.5">
          <i class="fa-solid fa-bullhorn text-xs"></i>
          <span>Report Fault For This Pole</span>
        </button>
      </div>
    `;

    marker.bindPopup(popupContent);
    liveMapMarkers.push(marker);
  });
}

function filterMapMarkers(status) {
  soundClick();
  activeMapFilter = status;
  ['all', 'active', 'faulty', 'in_repair'].forEach(s => {
    const btn = document.getElementById(`map-filter-${s === 'in_repair' ? 'repair' : s}`);
    if (btn) {
      if (s === status) {
        btn.className = 'px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-600 text-white transition';
      } else {
        btn.className = 'px-3 py-1.5 rounded-lg text-xs font-semibold bg-navy-900 text-slate-300 hover:text-white transition flex items-center gap-1.5 border border-blue-900/60';
      }
    }
  });
  renderLiveMapMarkers();
}

function filterMapByLocation(loc) {
  soundClick();
  activeMapLocation = loc;
  renderLiveMapMarkers();

  // If specific location selected, fly to that location's first pole
  if (loc !== 'all' && liveMap) {
    const locPole = poles.find(p => p.campusLocation === loc || p.ward === loc);
    if (locPole) {
      liveMap.flyTo([locPole.lat, locPole.lng], 17);
    }
  }
}

function reportFaultForPole(poleId) {
  switchView('report');
  const pole = poles.find(p => p.id === poleId);
  if (pole) {
    const wardSelect = document.getElementById('ward-select');
    const poleSelect = document.getElementById('pole-select');
    const addrInput = document.getElementById('address-input');

    if (wardSelect) {
      wardSelect.value = pole.campusLocation || pole.ward;
      populatePoleDropdowns();
    }
    if (poleSelect) poleSelect.value = pole.id;
    if (addrInput) addrInput.value = pole.street;

    if (pickerMap && pickerMarker) {
      pickerMarker.setLatLng([pole.lat, pole.lng]);
      pickerMap.setView([pole.lat, pole.lng], 17);
      updatePickedLocation(pole.lat, pole.lng);
    }
  }
}

// ================= PHOTO SELECTION & REMOVAL =================
function handlePhotoSelect(event) {
  const file = event.target.files[0];
  if (!file) return;

  if (file.size > 10 * 1024 * 1024) {
    showToast('Photo size must be under 10MB.', 'error');
    return;
  }

  selectedPhotoFile = file;
  const reader = new FileReader();
  reader.onload = function (e) {
    const preview = document.getElementById('photo-preview');
    const container = document.getElementById('photo-preview-container');
    const placeholder = document.getElementById('upload-placeholder');
    if (preview && container && placeholder) {
      preview.src = e.target.result;
      container.classList.remove('hidden');
      placeholder.classList.add('hidden');
    }
  };
  reader.readAsDataURL(file);
}

function removePhoto(event) {
  if (event) event.stopPropagation();
  selectedPhotoFile = null;
  const input = document.getElementById('photo-input');
  const preview = document.getElementById('photo-preview');
  const container = document.getElementById('photo-preview-container');
  const placeholder = document.getElementById('upload-placeholder');
  if (input) input.value = '';
  if (preview) preview.src = '#';
  if (container) container.classList.add('hidden');
  if (placeholder) placeholder.classList.remove('hidden');
}

// ================= FORM SUBMISSION =================
async function handleReportSubmit(e) {
  e.preventDefault();
  soundClick();

  const submitBtn = document.getElementById('submit-btn');
  const btnText = document.getElementById('submit-btn-text');
  if (submitBtn) submitBtn.disabled = true;
  if (btnText) btnText.innerText = 'Submitting to YIT Estates...';

  try {
    const formData = new FormData();
    const roleRadio = document.querySelector('input[name="reporterRole"]:checked');
    const role = roleRadio ? roleRadio.value : 'Student';
    const fullName = document.getElementById('citizen-name').value.trim();
    const idNumber = document.getElementById('reporter-id').value.trim();
    const mobile = document.getElementById('citizen-phone').value.trim();
    const dept = document.getElementById('reporter-dept').value;

    const campusLocation = document.getElementById('ward-select').value;
    const poleId = document.getElementById('pole-select').value;
    const address = document.getElementById('address-input').value.trim();
    const lat = document.getElementById('lat-input').value;
    const lng = document.getElementById('lng-input').value;

    const issueRadio = document.querySelector('input[name="issueType"]:checked');
    const issueType = issueRadio ? issueRadio.value : 'Completely Off';

    const priorityRadio = document.querySelector('input[name="priority"]:checked');
    const priority = priorityRadio ? priorityRadio.value : 'Standard';

    const description = document.getElementById('description-input').value.trim();

    formData.append('campusLocation', campusLocation);
    formData.append('wardZone', campusLocation);
    formData.append('poleId', poleId);
    formData.append('address', address);
    formData.append('issueType', issueType);
    formData.append('urgencyLevel', priority);
    formData.append('priority', priority);
    formData.append('description', description);

    formData.append('location', JSON.stringify({
      type: "Point",
      coordinates: [parseFloat(lng), parseFloat(lat)]
    }));

    formData.append('reporter', JSON.stringify({
      fullName: fullName,
      role: role,
      idNumber: idNumber,
      mobileNumber: mobile,
      email: `${idNumber.toLowerCase()}@example.invalid`,
      department: dept
    }));

    formData.append('citizenName', fullName);
    formData.append('citizenPhone', mobile);

    if (selectedPhotoFile) {
      formData.append('photo', selectedPhotoFile);
    }

    const res = await fetch('/api/tickets', {
      method: 'POST',
      body: formData
    });

    const json = await res.json();
    if (json.success && json.data) {
      soundSuccess();
      showSuccessModal(json.data);
      simulateSMS(mobile, `YIT Estates Grievance: Ticket ${json.data.ticketId} registered at ${campusLocation}. Campus electrician will inspect shortly.`);
      
      // Reset form
      removePhoto();
      document.getElementById('description-input').value = '';
      reloadAllData();
    } else {
      soundAlert();
      showToast(json.message || 'Submission failed. Please verify fields.', 'error');
    }
  } catch (err) {
    console.error('Submission error:', err);
    soundAlert();
    showToast('Failed to connect to backend server.', 'error');
  } finally {
    if (submitBtn) submitBtn.disabled = false;
    if (btnText) btnText.innerText = 'Submit Fault Report';
  }
}

// ================= SUCCESS MODAL & QR CODE =================
function showSuccessModal(ticket) {
  currentTicketModalId = ticket.ticketId || ticket._id;
  const modal = document.getElementById('modal-success');
  const ticketIdEl = document.getElementById('modal-ticket-id');
  const qrContainer = document.getElementById('modal-qrcode');

  if (ticketIdEl) ticketIdEl.innerText = currentTicketModalId;

  if (qrContainer) {
    qrContainer.innerHTML = '';
    const trackingUrl = `${window.location.origin}/?track=${currentTicketModalId}`;
    new QRCode(qrContainer, {
      text: trackingUrl,
      width: 140,
      height: 140,
      colorDark: '#040d1a',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
    });
  }

  if (modal) modal.classList.remove('hidden');
}

function closeSuccessModal() {
  const modal = document.getElementById('modal-success');
  if (modal) modal.classList.add('hidden');
}

function closeSuccessModalAndTrack() {
  closeSuccessModal();
  quickTrack(currentTicketModalId);
}

function copyTicketId() {
  soundClick();
  if (!currentTicketModalId) return;
  navigator.clipboard.writeText(currentTicketModalId);
  const btnText = document.getElementById('copy-btn-text');
  if (btnText) {
    btnText.innerText = 'Copied!';
    setTimeout(() => btnText.innerText = 'Copy', 2000);
  }
  showToast(`Ticket ${currentTicketModalId} copied to clipboard`, 'info');
}

// ================= COMPLAINT TRACKING =================
async function handleTrackSearch() {
  soundClick();
  const input = document.getElementById('track-input');
  const query = input ? input.value.trim() : '';
  if (!query) {
    showToast('Please enter a Ticket ID or Student USN / Mobile number.', 'warning');
    return;
  }
  trackTicket(query);
}

function quickTrack(id) {
  const input = document.getElementById('track-input');
  if (input) input.value = id;
  switchView('track');
  trackTicket(id);
}

async function trackTicket(query) {
  const container = document.getElementById('track-result-container');
  if (!container) return;

  container.innerHTML = `
    <div class="glass-panel p-8 rounded-2xl border border-blue-900/50 text-center">
      <i class="fa-solid fa-rotate animate-spin text-2xl text-sky-400 mb-2"></i>
      <p class="text-xs text-slate-300">Searching YIT grievance database...</p>
    </div>
  `;
  container.classList.remove('hidden');

  try {
    const res = await fetch(`/api/tickets/${encodeURIComponent(query)}`);
    const json = await res.json();

    if (json.success && json.data) {
      renderTrackDetails(json.data);
    } else {
      container.innerHTML = `
        <div class="glass-panel p-8 rounded-2xl border border-rose-500/30 text-center">
          <i class="fa-solid fa-circle-question text-3xl text-rose-400 mb-2"></i>
          <h3 class="text-base font-bold text-white">No Grievance Record Found</h3>
          <p class="text-xs text-slate-400 mt-1">We couldn't locate any ticket matching "<span class="font-mono text-sky-300">${escapeHtml(query)}</span>". Please check your Ticket ID or USN.</p>
        </div>
      `;
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = `
      <div class="glass-panel p-8 rounded-2xl border border-rose-500/30 text-center">
        <i class="fa-solid fa-triangle-exclamation text-3xl text-rose-400 mb-2"></i>
        <p class="text-xs text-slate-400">Failed to connect to campus server.</p>
      </div>
    `;
  }
}

function renderTrackDetails(ticket) {
  const container = document.getElementById('track-result-container');
  if (!container) return;

  const stages = ['Submitted', 'Under Review', 'Assigned', 'In Progress', 'Resolved'];
  const currentStageIndex = stages.indexOf(ticket.status) !== -1 ? stages.indexOf(ticket.status) : 0;

  let assignedTechHtml = '';
  if (ticket.assignedTechName || ticket.assignedTechnicianId) {
    const tech = technicians.find(t => t.id === (ticket.assignedTechnicianId || ticket.assignedTechId)) || {
      name: ticket.assignedTechName || 'Campus Maintenance Electrician',
      phone: '+91 98451 23456',
      designation: 'Campus Electrician'
    };

    assignedTechHtml = `
      <div class="p-4 rounded-xl bg-blue-950/40 border border-blue-800/40 flex items-center justify-between flex-wrap gap-3">
        <div class="flex items-center space-x-3">
          <div class="w-10 h-10 rounded-full bg-blue-600/30 text-sky-400 flex items-center justify-center font-bold text-sm">
            <i class="fa-solid fa-helmet-safety"></i>
          </div>
          <div>
            <div class="text-[10px] text-sky-400 uppercase font-bold tracking-wider">Assigned Electrician</div>
            <strong class="text-sm text-white">${escapeHtml(tech.name)}</strong>
            <span class="text-xs text-slate-400 block">${escapeHtml(tech.designation || 'Electrician')}</span>
          </div>
        </div>
        <a href="tel:${escapeHtml(tech.phone)}" class="px-3.5 py-1.5 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-600/30 transition flex items-center gap-1.5">
          <i class="fa-solid fa-phone"></i>
          <span>Call ${escapeHtml(tech.phone)}</span>
        </a>
      </div>
    `;
  }

  // Feedback section if resolved
  let feedbackHtml = '';
  if (ticket.status === 'Resolved') {
    if (ticket.rating) {
      feedbackHtml = `
        <div class="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
          <div class="flex items-center gap-2 mb-1">
            <span class="text-xs font-bold text-emerald-400">Reporter Feedback:</span>
            <span class="text-yellow-400 text-xs">⭐ ${ticket.rating} / 5</span>
          </div>
          <p class="text-xs text-slate-300 italic">"${escapeHtml(ticket.feedback || 'Restored and verified.')}"</p>
        </div>
      `;
    } else {
      feedbackHtml = `
        <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60 space-y-3">
          <div class="flex items-center justify-between">
            <strong class="text-xs font-bold text-white">Rate the Repair Service</strong>
            <span class="text-[10px] text-slate-400">Help improve campus facilities</span>
          </div>
          <div class="flex items-center gap-2">
            <label class="text-xs text-slate-300">Rating:</label>
            <select id="feedback-rating-${ticket._id}" class="bg-navy-900 border border-blue-900 text-white text-xs rounded-lg px-2 py-1">
              <option value="5">⭐⭐⭐⭐⭐ Excellent (5)</option>
              <option value="4">⭐⭐⭐⭐ Good (4)</option>
              <option value="3">⭐⭐⭐ Satisfactory (3)</option>
              <option value="2">⭐⭐ Needs Improvement (2)</option>
              <option value="1">⭐ Poor (1)</option>
            </select>
          </div>
          <input type="text" id="feedback-text-${ticket._id}" placeholder="Leave a brief comment (e.g. 'Repaired promptly, thank you!')" class="w-full bg-navy-900 border border-blue-900 text-xs text-white rounded-lg px-3 py-2">
          <button onclick="submitStudentFeedback('${ticket._id}')" class="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-lg transition shadow-md shadow-blue-600/30">
            Submit Rating
          </button>
        </div>
      `;
    }
  }

  container.innerHTML = `
    <div class="glass-panel p-6 sm:p-8 rounded-2xl border border-blue-900/50 space-y-6 shadow-2xl">
      <!-- Header Badge -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-blue-900/60">
        <div>
          <span class="text-[10px] text-sky-400 font-mono uppercase tracking-wider block">Yenepoya Institute of Technology</span>
          <div class="flex items-center gap-3">
            <h3 class="text-xl font-black text-white font-mono">${escapeHtml(ticket.ticketId || ticket._id)}</h3>
            <span class="px-2.5 py-0.5 rounded-full text-xs font-extrabold ${getStatusBadgeClass(ticket.status)}">
              ${escapeHtml(ticket.status)}
            </span>
          </div>
        </div>
        <div class="text-xs text-slate-300 text-left sm:text-right">
          <div>Reported: <span class="font-medium text-slate-200">${new Date(ticket.createdAt).toLocaleString()}</span></div>
          <div>Pole Code: <span class="font-mono text-sky-300 font-bold">${escapeHtml(ticket.poleCode || 'YIT-GEN')}</span></div>
        </div>
      </div>

      <!-- 5-STAGE PROGRESS TIMELINE -->
      <div>
        <div class="text-xs font-bold text-slate-300 mb-3 uppercase tracking-wider">Campus Work Order Progress</div>
        <div class="grid grid-cols-5 gap-1.5 text-center">
          ${stages.map((stage, idx) => {
            const isDone = idx <= currentStageIndex;
            const isCurrent = idx === currentStageIndex;
            return `
              <div class="flex flex-col items-center">
                <div class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${isCurrent ? 'bg-sky-400 text-slate-950 ring-4 ring-sky-400/30 shadow-lg' : isDone ? 'bg-emerald-600 text-white' : 'bg-navy-900 text-slate-500 border border-blue-900'}">
                  ${isDone ? '<i class="fa-solid fa-check"></i>' : idx + 1}
                </div>
                <span class="text-[10px] mt-1.5 font-bold ${isCurrent ? 'text-sky-400' : isDone ? 'text-slate-200' : 'text-slate-500'} line-clamp-1">${stage}</span>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Fault Details Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-navy-950/70 p-4 rounded-xl border border-blue-900/60">
        <div>
          <span class="text-slate-400 block">Campus Location:</span>
          <strong class="text-sky-300 text-sm flex items-center gap-1.5 mt-0.5">
            <i class="fa-solid fa-building-columns text-sky-400"></i>
            ${escapeHtml(ticket.campusLocation || ticket.wardZone)}
          </strong>
          <span class="text-slate-400 block mt-1">${escapeHtml(ticket.address)}</span>
        </div>

        <div>
          <span class="text-slate-400 block">Reported By:</span>
          <strong class="text-white text-sm block mt-0.5">${escapeHtml(ticket.reporter?.fullName || ticket.citizenName)}</strong>
          <span class="text-sky-300 font-semibold">${escapeHtml(ticket.reporter?.role || 'Student')}</span>
          ${ticket.reporter?.idNumber ? `<span class="text-slate-400"> • USN/ID: <strong class="text-slate-200 font-mono">${escapeHtml(ticket.reporter.idNumber)}</strong></span>` : ''}
        </div>

        <div>
          <span class="text-slate-400 block">Issue Category:</span>
          <span class="font-bold text-white text-sm block mt-0.5">${escapeHtml(ticket.issueType)}</span>
        </div>

        <div>
          <span class="text-slate-400 block">Urgency Level:</span>
          <span class="font-bold text-sm block mt-0.5 ${ticket.urgencyLevel === 'Emergency Hazard' ? 'text-rose-400' : ticket.urgencyLevel === 'High Priority' ? 'text-amber-400' : 'text-slate-200'}">${escapeHtml(ticket.urgencyLevel || ticket.priority)}</span>
        </div>

        <div class="sm:col-span-2 pt-1 border-t border-blue-950">
          <span class="text-slate-400 block mb-0.5">Description & Remarks:</span>
          <p class="text-slate-200 leading-relaxed">${escapeHtml(ticket.description || 'No additional remarks.')}</p>
        </div>
      </div>

      <!-- Photo Evidence & Resolution Photo -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        ${ticket.photoUrl ? `
          <div class="p-3 bg-navy-950 rounded-xl border border-blue-900/60">
            <span class="text-[10px] text-slate-400 block mb-1.5 font-bold">FAULT PHOTO AT SUBMISSION</span>
            <img src="${escapeHtml(ticket.photoUrl)}" alt="Fault" class="max-h-48 rounded-lg border border-blue-900 object-cover w-full">
          </div>
        ` : ''}

        ${ticket.resolutionPhoto ? `
          <div class="p-3 bg-navy-950 rounded-xl border border-emerald-500/30">
            <span class="text-[10px] text-emerald-400 block mb-1.5 font-bold">VERIFIED REPAIR PROOF PHOTO</span>
            <img src="${escapeHtml(ticket.resolutionPhoto)}" alt="Restored" class="max-h-48 rounded-lg border border-emerald-500/40 object-cover w-full">
          </div>
        ` : ''}
      </div>

      <!-- Assigned Technician Card -->
      ${assignedTechHtml}

      <!-- Repair Notes if any -->
      ${ticket.repairNotes ? `
        <div class="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30">
          <span class="text-[10px] text-emerald-400 uppercase font-bold tracking-wider block mb-1">Work Done / Parts Replaced</span>
          <p class="text-xs text-slate-200 leading-relaxed">${escapeHtml(ticket.repairNotes)}</p>
        </div>
      ` : ''}

      <!-- Student Feedback -->
      ${feedbackHtml}

      <!-- Audit History Trail -->
      <div>
        <div class="text-xs font-bold text-slate-300 mb-2 uppercase tracking-wider">Audit Log & Updates</div>
        <div class="space-y-2 border-l-2 border-blue-900 pl-3">
          ${(ticket.history || []).map(h => `
            <div class="text-xs">
              <span class="text-sky-300 font-bold">${escapeHtml(h.status)}</span>
              <span class="text-slate-400 text-[10px] ml-1.5">${new Date(h.timestamp).toLocaleString()}</span>
              <p class="text-slate-300 text-[11px] mt-0.5">${escapeHtml(h.note)}</p>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function getStatusBadgeClass(status) {
  switch (status) {
    case 'Resolved': return 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40';
    case 'In Progress': return 'bg-amber-500/20 text-amber-300 border border-amber-500/40';
    case 'Assigned': return 'bg-blue-500/20 text-sky-300 border border-blue-500/40';
    case 'Under Review': return 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40';
    default: return 'bg-slate-500/20 text-slate-300 border border-slate-500/40';
  }
}

async function submitStudentFeedback(ticketId) {
  soundClick();
  const ratingEl = document.getElementById(`feedback-rating-${ticketId}`);
  const textEl = document.getElementById(`feedback-text-${ticketId}`);
  const rating = ratingEl ? ratingEl.value : 5;
  const feedback = textEl ? textEl.value.trim() : 'Service verified.';

  try {
    const res = await fetch(`/api/tickets/${ticketId}/feedback`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating, feedback })
    });
    const json = await res.json();
    if (json.success) {
      soundSuccess();
      showToast('Thank you! Your feedback has been recorded.', 'success');
      trackTicket(ticketId);
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to record feedback.', 'error');
  }
}

// ================= MY COMPLAINTS (Student Personal Dashboard) =================
async function renderMyComplaints() {
  const container = document.getElementById('my-complaints-list');
  const title = document.getElementById('my-complaints-title');
  const subtitle = document.getElementById('my-complaints-subtitle');
  if (!container) return;

  if (title) title.innerText = `${currentUser.name}'s Reported Grievances`;
  if (subtitle) subtitle.innerText = `Logged in as ${currentUser.role} • ${currentUser.idNumber || currentUser.phone} • ${currentUser.department}`;

  let studentComplaints = [];
  try {
    const response = await fetch('/api/my/tickets');
    const result = await response.json();
    if (response.ok && result.success) studentComplaints = result.data || [];
  } catch (error) { console.error('Could not load your tickets:', error); }

  if (studentComplaints.length === 0) {
    container.innerHTML = `
      <div class="glass-panel p-8 rounded-2xl border border-blue-900/50 text-center space-y-3">
        <div class="w-12 h-12 rounded-full bg-blue-600/20 text-sky-400 flex items-center justify-center mx-auto text-xl">
          <i class="fa-solid fa-clipboard-check"></i>
        </div>
        <h3 class="text-base font-bold text-white">No Complaints Logged Under This Account</h3>
        <p class="text-xs text-slate-400">Notice a dark walkway or faulty light on campus? Report it right now!</p>
        <button onclick="switchView('report')" class="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition shadow-md shadow-blue-600/30">
          Report Streetlight Malfunction
        </button>
      </div>
    `;
    return;
  }

  container.innerHTML = studentComplaints.map(c => `
    <div class="glass-panel p-5 rounded-2xl border border-blue-900/50 space-y-3 hover:border-sky-400/50 transition">
      <div class="flex items-center justify-between pb-2 border-b border-blue-950">
        <div class="flex items-center gap-2.5">
          <span class="font-mono text-sm font-black text-sky-400">${escapeHtml(c.ticketId || c._id)}</span>
          <span class="px-2 py-0.5 rounded text-[10px] font-bold ${getStatusBadgeClass(c.status)}">${escapeHtml(c.status)}</span>
        </div>
        <span class="text-[10px] text-slate-400">${new Date(c.createdAt).toLocaleDateString()}</span>
      </div>

      <div class="text-xs text-slate-200">
        <strong class="text-sm text-white block">${escapeHtml(c.issueType)} at ${escapeHtml(c.campusLocation || c.wardZone)}</strong>
        <p class="text-slate-400 text-[11px] mt-0.5">${escapeHtml(c.address)}</p>
      </div>

      <div class="flex items-center justify-between pt-2 text-xs">
        <span class="text-[11px] text-sky-300">
          <i class="fa-solid fa-helmet-safety mr-1"></i>
          ${c.assignedTechName ? `Electrician: ${escapeHtml(c.assignedTechName)}` : 'Queued for Dispatch'}
        </span>
        <button onclick="quickTrack('${escapeHtml(c.ticketId || c._id)}')" class="px-3 py-1 bg-navy-800 hover:bg-navy-750 text-white font-bold rounded-lg border border-blue-800/40 text-[11px] transition">
          View Live Timeline &rarr;
        </button>
      </div>
    </div>
  `).join('');
}

// ================= MAINTENANCE DASHBOARD (ADMIN) =================
let adminSearchDebounceTimer = null;
function debounceAdminSearch() {
  clearTimeout(adminSearchDebounceTimer);
  adminSearchDebounceTimer = setTimeout(loadAdminComplaints, 300);
}

async function loadAdminComplaints() {
  const searchInput = document.getElementById('admin-search-input');
  const statusSelect = document.getElementById('admin-filter-status');
  const wardSelect = document.getElementById('admin-filter-ward');
  const prioritySelect = document.getElementById('admin-filter-priority');

  const queryParams = new URLSearchParams();
  if (searchInput && searchInput.value.trim()) queryParams.append('search', searchInput.value.trim());
  if (statusSelect && statusSelect.value !== 'All') queryParams.append('status', statusSelect.value);
  if (wardSelect && wardSelect.value !== 'All') queryParams.append('campusLocation', wardSelect.value);
  if (prioritySelect && prioritySelect.value !== 'All') queryParams.append('priority', prioritySelect.value);

  try {
    const res = await fetch(`/api/tickets?${queryParams.toString()}`);
    const json = await res.json();
    if (json.success) {
      complaints = json.data || [];
      renderAdminComplaintsTable(complaints);
    }
  } catch (err) {
    console.error('Failed to load admin complaints:', err);
  }
}

function renderAdminComplaintsTable(data) {
  const tbody = document.getElementById('admin-complaints-tbody');
  if (!tbody) return;

  if (data.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="py-8 text-center text-slate-400 text-xs">
          No complaints found matching the selected filters.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = data.map(c => `
    <tr class="hover:bg-blue-950/30 transition">
      <td class="py-3 px-4 font-mono font-bold text-sky-400">
        <a href="javascript:void(0)" onclick="quickTrack('${escapeHtml(c.ticketId || c._id)}')" class="hover:underline">${escapeHtml(c.ticketId || c._id)}</a>
      </td>
      <td class="py-3 px-4">
        <div class="font-semibold text-white">${escapeHtml(c.campusLocation || c.wardZone)}</div>
        <div class="text-[10px] text-slate-400 truncate max-w-xs">${escapeHtml(c.address)}</div>
      </td>
      <td class="py-3 px-4">
        <span class="font-medium text-slate-200">${escapeHtml(c.issueType)}</span>
      </td>
      <td class="py-3 px-4">
        <span class="font-bold ${c.urgencyLevel === 'Emergency Hazard' ? 'text-rose-400' : c.urgencyLevel === 'High Priority' ? 'text-amber-400' : 'text-slate-300'}">${escapeHtml(c.urgencyLevel || c.priority)}</span>
      </td>
      <td class="py-3 px-4">
        <div class="font-medium text-slate-200">${escapeHtml(c.reporter?.fullName || c.citizenName)}</div>
        <div class="text-[10px] text-sky-400 font-mono">${escapeHtml(c.reporter?.idNumber || c.reporter?.role || 'Student')}</div>
      </td>
      <td class="py-3 px-4">
        <span class="px-2 py-0.5 rounded text-[10px] font-bold ${getStatusBadgeClass(c.status)}">
          ${escapeHtml(c.status)}
        </span>
      </td>
      <td class="py-3 px-4">
        <span class="text-xs text-slate-200">${escapeHtml(c.assignedTechName || 'Unassigned')}</span>
      </td>
      <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
        <button onclick="openAssignModal('${c._id}')" class="px-2.5 py-1 bg-navy-800 hover:bg-navy-750 text-sky-400 border border-blue-900 rounded-lg text-[11px] font-bold transition">
          <i class="fa-solid fa-user-plus mr-1"></i> Assign
        </button>
        <button onclick="openResolveModal('${c._id}')" class="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 rounded-lg text-[11px] font-bold transition">
          <i class="fa-solid fa-check mr-1"></i> Resolve
        </button>
      </td>
    </tr>
  `).join('');
}

// ================= ANALYTICS & CHARTS =================
async function loadAnalytics() {
  try {
    const res = await fetch('/api/analytics');
    const json = await res.json();
    if (json.success && json.data) {
      renderAnalyticsCharts(json.data);
    }
  } catch (err) {
    console.error('Failed to load analytics:', err);
  }
}

function renderAnalyticsCharts(data) {
  // 1. Campus Location bars (The 7 Locations)
  const wardContainer = document.getElementById('chart-ward-bars');
  if (wardContainer) {
    const locations = CAMPUS_LOCATIONS;
    const maxVal = Math.max(...locations.map(loc => data.byLocation[loc] || 0), 1);

    wardContainer.innerHTML = locations.map(loc => {
      const count = data.byLocation[loc] || 0;
      const pct = Math.round((count / maxVal) * 100);
      return `
        <div>
          <div class="flex justify-between text-[11px] mb-0.5">
            <span class="text-slate-300 font-medium">${loc}</span>
            <span class="font-bold text-sky-400 font-mono">${count}</span>
          </div>
          <div class="w-full bg-navy-950 rounded-full h-2 overflow-hidden border border-blue-950">
            <div class="bg-blue-600 h-full rounded-full transition-all duration-500" style="width: ${pct}%"></div>
          </div>
        </div>
      `;
    }).join('');
  }

  // 2. Failure types bars
  const issueContainer = document.getElementById('chart-issue-bars');
  if (issueContainer && data.byIssue) {
    const issues = Object.keys(data.byIssue);
    const maxVal = Math.max(...Object.values(data.byIssue), 1);

    issueContainer.innerHTML = issues.map(issue => {
      const count = data.byIssue[issue] || 0;
      const pct = Math.round((count / maxVal) * 100);
      return `
        <div>
          <div class="flex justify-between text-[11px] mb-0.5">
            <span class="text-slate-300 font-medium">${issue}</span>
            <span class="font-bold text-amber-400 font-mono">${count}</span>
          </div>
          <div class="w-full bg-navy-950 rounded-full h-2 overflow-hidden border border-blue-950">
            <div class="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full transition-all duration-500" style="width: ${pct}%"></div>
          </div>
        </div>
      `;
    }).join('');
  }

  // 3. Energy metrics
  if (data.energyMetrics) {
    const kwhEl = document.getElementById('metric-wasted-kwh');
    const costEl = document.getElementById('metric-wasted-cost');
    const co2El = document.getElementById('metric-co2');
    if (kwhEl) kwhEl.innerText = data.energyMetrics.wastedKwhPerDay;
    if (costEl) costEl.innerText = `₹ ${data.energyMetrics.wastedCostPerMonth}`;
    if (co2El) co2El.innerText = `${data.energyMetrics.co2KgPerMonth} kg/mo`;
  }

  if (data.citizenSatisfaction) {
    const satEl = document.getElementById('metric-satisfaction');
    if (satEl) satEl.innerText = `⭐ ${data.citizenSatisfaction.averageRating} / 5.0`;
  }
}

// ================= MONTHLY MAINTENANCE REPORTS =================
async function loadMonthlyReport() {
  const monthPicker = document.getElementById('report-month-picker');
  const month = monthPicker ? monthPicker.value : '2026-11';
  const container = document.getElementById('monthly-report-content');
  if (!container) return;

  container.innerHTML = `
    <div class="p-8 text-center">
      <i class="fa-solid fa-rotate animate-spin text-2xl text-sky-400 mb-2"></i>
      <p class="text-xs text-slate-300">Generating YIT Monthly Maintenance Audit...</p>
    </div>
  `;

  try {
    const res = await fetch(`/api/reports/monthly?month=${month}`);
    const json = await res.json();
    if (json.success && json.data) {
      renderMonthlyReport(json.data);
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = `<div class="p-6 text-center text-rose-400 text-xs">Failed to generate monthly report.</div>`;
  }
}

function renderMonthlyReport(report) {
  const container = document.getElementById('monthly-report-content');
  if (!container) return;

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const [year, mNum] = report.month.split('-');
  const monthLabel = `${monthNames[parseInt(mNum) - 1]} ${year}`;

  container.innerHTML = `
    <!-- Official Institutional Letterhead -->
    <div class="border-b-2 border-blue-700/60 pb-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
      <div class="flex items-center gap-4">
        <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-700 to-sky-400 flex items-center justify-center text-white font-black text-2xl shadow-xl shrink-0">
          <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <div>
          <h2 class="text-xl sm:text-2xl font-black text-white tracking-tight">Yenepoya Institute of Technology</h2>
          <p class="text-xs text-sky-300 font-semibold">Campus Estates & Maintenance Division • Moodbidri, Mangalore - 574225</p>
          <p class="text-[10px] text-slate-400">Approved by AICTE, New Delhi | Affiliated to Visvesvaraya Technological University (VTU), Belagavi</p>
        </div>
      </div>
      <div class="text-center sm:text-right">
        <div class="text-xs font-bold text-sky-400 uppercase tracking-widest font-mono">Monthly Maintenance Audit</div>
        <div class="text-base font-black text-white mt-0.5">${monthLabel}</div>
        <div class="text-[10px] text-slate-400">Generated: ${new Date(report.generatedAt).toLocaleDateString()}</div>
      </div>
    </div>

    <!-- Executive KPI Summary Cards -->
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
      <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60">
        <span class="text-[10px] text-slate-400 uppercase font-bold block">Campus Poles Monitored</span>
        <strong class="text-2xl font-black text-white font-mono">${report.totalPoles}</strong>
        <span class="text-[10px] text-emerald-400 block mt-0.5">${report.uptimePercent}% Campus Uptime</span>
      </div>

      <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60">
        <span class="text-[10px] text-slate-400 uppercase font-bold block">Faults Logged</span>
        <strong class="text-2xl font-black text-amber-400 font-mono">${report.totalReported}</strong>
        <span class="text-[10px] text-slate-400 block mt-0.5">Students & Staff</span>
      </div>

      <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60">
        <span class="text-[10px] text-slate-400 uppercase font-bold block">Faults Resolved</span>
        <strong class="text-2xl font-black text-emerald-400 font-mono">${report.totalResolved}</strong>
        <span class="text-[10px] text-emerald-400 block mt-0.5">${report.resolutionRate} Resolution SLA</span>
      </div>

      <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60">
        <span class="text-[10px] text-slate-400 uppercase font-bold block">Average Turnaround</span>
        <strong class="text-2xl font-black text-sky-400 font-mono">${report.averageResolutionHours}h</strong>
        <span class="text-[10px] text-slate-400 block mt-0.5">Campus SLA Target: &lt;6h</span>
      </div>

      <div class="p-4 rounded-xl bg-navy-950 border border-blue-900/60">
        <span class="text-[10px] text-slate-400 uppercase font-bold block">Energy Conserved</span>
        <strong class="text-2xl font-black text-sky-300 font-mono">${report.energySavedKwh}</strong>
        <span class="text-[10px] text-emerald-400 block mt-0.5">kWh (₹ ${report.costSavedInr} saved)</span>
      </div>
    </div>

    <!-- Campus Locations Performance Table (The 7 Locations) -->
    <div class="space-y-3">
      <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
        <i class="fa-solid fa-building-columns text-sky-400"></i>
        <span>Campus Zone Maintenance Performance</span>
      </h3>
      <div class="overflow-x-auto rounded-xl border border-blue-900/60">
        <table class="w-full text-left text-xs">
          <thead class="bg-navy-900 text-slate-300 font-bold uppercase tracking-wider border-b border-blue-900">
            <tr>
              <th class="py-2.5 px-4">Campus Location</th>
              <th class="py-2.5 px-4">Monitored Poles</th>
              <th class="py-2.5 px-4">Faults Logged</th>
              <th class="py-2.5 px-4">Restored</th>
              <th class="py-2.5 px-4">Pending</th>
              <th class="py-2.5 px-4 text-right">Zone Health</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-blue-950 bg-navy-950/70">
            ${report.locationStats.map(s => {
              const healthPct = s.totalPoles > 0 ? Math.round(((s.totalPoles - s.pending) / s.totalPoles) * 100) : 100;
              return `
                <tr>
                  <td class="py-2.5 px-4 font-bold text-white">${escapeHtml(s.location)}</td>
                  <td class="py-2.5 px-4 font-mono text-slate-300">${s.totalPoles}</td>
                  <td class="py-2.5 px-4 font-mono text-amber-400 font-bold">${s.faultsReported}</td>
                  <td class="py-2.5 px-4 font-mono text-emerald-400 font-bold">${s.faultsResolved}</td>
                  <td class="py-2.5 px-4 font-mono ${s.pending > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'}">${s.pending}</td>
                  <td class="py-2.5 px-4 text-right">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ${healthPct >= 90 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}">${healthPct}%</span>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Campus Electrician Performance Log -->
    <div class="space-y-3">
      <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
        <i class="fa-solid fa-helmet-safety text-sky-400"></i>
        <span>Campus Electrical Maintenance Staff Workload</span>
      </h3>
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        ${report.technicianStats.map(t => `
          <div class="p-3.5 rounded-xl bg-navy-950 border border-blue-900/60 space-y-1.5">
            <div class="flex items-center justify-between">
              <strong class="text-xs text-white font-bold">${escapeHtml(t.name)}</strong>
              <span class="text-[10px] text-sky-400 font-mono">${escapeHtml(t.id)}</span>
            </div>
            <span class="text-[11px] text-slate-400 block">${escapeHtml(t.designation)}</span>
            <div class="flex items-center justify-between text-xs pt-1 border-t border-blue-950">
              <span class="text-slate-400">Assigned: <strong class="text-white font-mono">${t.assigned}</strong></span>
              <span class="text-emerald-400 font-bold">Resolved: <strong class="font-mono">${t.resolved}</strong></span>
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Official Verification & Signatures Block -->
    <div class="pt-8 border-t border-blue-900/70 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs">
      <div>
        <div class="h-12 border-b border-dashed border-blue-800 mb-2 flex items-end justify-center pb-1 text-slate-400 italic">
          Campus Technician 1
        </div>
        <strong class="text-white block">Senior Campus Electrician</strong>
        <span class="text-[10px] text-slate-400">Field Maintenance Division</span>
      </div>

      <div>
        <div class="h-12 border-b border-dashed border-blue-800 mb-2 flex items-end justify-center pb-1 text-slate-400 italic">
          Campus Estates Officer
        </div>
        <strong class="text-white block">Estates & Facilities Officer</strong>
        <span class="text-[10px] text-slate-400">Yenepoya Institute of Technology</span>
      </div>

      <div>
        <div class="h-12 border-b border-dashed border-blue-800 mb-2 flex items-end justify-center pb-1 text-slate-400 italic">
          Dr. Principal, Ph.D.
        </div>
        <strong class="text-white block">Principal, YIT Moodbidri</strong>
        <span class="text-[10px] text-slate-400">Official Institutional Approval</span>
      </div>
    </div>
  `;
}

function downloadCSVReport() {
  soundClick();
  window.location.href = '/api/export/csv';
  showToast('Downloading campus fault report CSV...', 'info');
}

// ================= ASSIGN & RESOLVE MODALS =================
function openAssignModal(ticketId) {
  soundClick();
  currentAssignTicketId = ticketId;
  const modal = document.getElementById('modal-assign');
  const ticketLabel = document.getElementById('assign-modal-ticket');
  if (ticketLabel) ticketLabel.innerText = ticketId;
  if (modal) modal.classList.remove('hidden');
}

function closeAssignModal() {
  const modal = document.getElementById('modal-assign');
  if (modal) modal.classList.add('hidden');
}

async function submitAssignTechnician() {
  soundClick();
  const techId = document.getElementById('assign-tech-select').value;
  const note = document.getElementById('assign-note').value.trim();

  try {
    const res = await fetch(`/api/tickets/${currentAssignTicketId}/assign`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ techId, note })
    });
    const json = await res.json();
    if (json.success) {
      soundSuccess();
      closeAssignModal();
      showToast('Work order dispatched to electrician!', 'success');
      reloadAllData();
    } else {
      soundAlert();
      showToast(json.message || 'Failed to assign.', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to assign technician.', 'error');
  }
}

function openResolveModal(ticketId) {
  soundClick();
  currentResolveTicketId = ticketId;
  const modal = document.getElementById('modal-resolve');
  const ticketLabel = document.getElementById('resolve-modal-ticket');
  if (ticketLabel) ticketLabel.innerText = ticketId;
  if (modal) modal.classList.remove('hidden');
}

function closeResolveModal() {
  const modal = document.getElementById('modal-resolve');
  if (modal) modal.classList.add('hidden');
}

async function submitResolveTicket() {
  soundClick();
  const notes = document.getElementById('resolve-notes').value.trim();
  const photoInput = document.getElementById('resolve-photo-input');
  const activeTechSelect = document.getElementById('active-technician-select');
  const techName = activeTechSelect ? activeTechSelect.options[activeTechSelect.selectedIndex]?.text.split('(')[0].trim() : 'Campus Electrician';

  if (!notes) {
    showToast('Please enter repair notes / work done description.', 'warning');
    return;
  }

  const formData = new FormData();
  formData.append('repairNotes', notes);
  formData.append('technicianName', techName);

  if (photoInput && photoInput.files[0]) {
    formData.append('resolutionPhoto', photoInput.files[0]);
  }

  try {
    const res = await fetch(`/api/tickets/${currentResolveTicketId}/resolve`, {
      method: 'POST',
      body: formData
    });
    const json = await res.json();
    if (json.success) {
      soundSuccess();
      closeResolveModal();
      showToast('Complaint resolved and verified!', 'success');
      reloadAllData();
    } else {
      soundAlert();
      showToast(json.message || 'Failed to resolve ticket.', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to connect to server.', 'error');
  }
}

// ================= ADD NEW POLE MODAL =================
function openAddPoleModal() {
  soundClick();
  const modal = document.getElementById('modal-add-pole');
  if (modal) modal.classList.remove('hidden');
}

function closeAddPoleModal() {
  const modal = document.getElementById('modal-add-pole');
  if (modal) modal.classList.add('hidden');
}

async function submitNewPole(e) {
  e.preventDefault();
  soundClick();

  const code = document.getElementById('new-pole-code').value.trim();
  const street = document.getElementById('new-pole-street').value.trim();
  const ward = document.getElementById('new-pole-ward').value;
  const wattage = document.getElementById('new-pole-wattage').value;
  const lat = document.getElementById('new-pole-lat').value;
  const lng = document.getElementById('new-pole-lng').value;

  try {
    const res = await fetch('/api/poles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code,
        street,
        campusLocation: ward,
        ward,
        wattage,
        lat,
        lng,
        type: 'LED 90W Smart'
      })
    });
    const json = await res.json();
    if (json.success) {
      soundSuccess();
      closeAddPoleModal();
      showToast(`Pole ${json.data.code} registered at ${ward}`, 'success');
      reloadAllData();
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to deploy pole.', 'error');
  }
}

// ================= IOT SIMULATION MODAL =================
function openIoTModal() {
  soundClick();
  const modal = document.getElementById('modal-iot');
  if (modal) modal.classList.remove('hidden');
}

function closeIoTModal() {
  const modal = document.getElementById('modal-iot');
  if (modal) modal.classList.add('hidden');
}

async function triggerIoTSimulation() {
  soundClick();
  const poleCode = document.getElementById('iot-pole-select').value;
  const faultRadio = document.querySelector('input[name="iot-fault"]:checked');
  const faultType = faultRadio ? faultRadio.value : 'Zero Current (Bulb Burnout)';

  const triggerBtn = document.getElementById('iot-trigger-btn');
  if (triggerBtn) triggerBtn.disabled = true;

  try {
    const res = await fetch('/api/iot/simulate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        poleCode,
        faultType: faultType.includes('Day') ? 'Day-Burning' : faultType.includes('Tamper') ? 'Wire Hazard' : faultType.includes('Surge') ? 'Flickering' : 'Completely Off'
      })
    });

    const json = await res.json();
    if (json.success) {
      soundAlert();
      closeIoTModal();
      showToast(`IoT telemetry triggered for ${poleCode}!`, 'warning');
      reloadAllData();
    }
  } catch (err) {
    console.error(err);
    showToast('Failed to simulate IoT telemetry.', 'error');
  } finally {
    if (triggerBtn) triggerBtn.disabled = false;
  }
}

// ================= INITIALIZATION =================
document.addEventListener('DOMContentLoaded', () => {
  // Init map & form handlers
  initPickerMap();
  loadCurrentUser();
  applyUserSession();

  const reportForm = document.getElementById('report-form');
  if (reportForm) {
    reportForm.addEventListener('submit', handleReportSubmit);
  }

  // Load all initial data
  reloadAllData();

  // Check URL query parameters for direct tracking (?track=YIT-2026-XXXX)
  const urlParams = new URLSearchParams(window.location.search);
  const trackId = urlParams.get('track');
  if (trackId) {
    quickTrack(trackId);
  }

  // Polling for live status updates every 25 seconds
  setInterval(() => {
    reloadAllData(false);
  }, 25000);
});
