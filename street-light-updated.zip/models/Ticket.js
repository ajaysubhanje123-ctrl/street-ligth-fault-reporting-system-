/**
 * Ticket Model Definition
 * Standardized ticket schema for Yenepoya Institute of Technology (YIT) Moodbidri
 * Campus Street Light Fault Reporting & Maintenance System (YIT SmartLight).
 */

const CAMPUS_LOCATIONS = [
  'Main College Building',
  'College Entrance',
  'Campus Roads',
  'Parking Area',
  'Hostel Area',
  'Playground',
  'Library Area'
];

const TICKET_STATUSES = [
  'Submitted',
  'Pending',
  'Under Review',
  'Assigned',
  'In Progress',
  'Resolved',
  'Rejected'
];

const URGENCY_LEVELS = [
  'Standard',
  'High Priority',
  'Emergency Hazard'
];

const ISSUE_TYPES = [
  'Completely Off',
  'Flickering',
  'Wire Hazard',
  'Day-Burning',
  'Broken Fixture',
  'Dim Illumination'
];

/**
 * Normalizes status values across legacy and new formats
 */
function normalizeStatus(status) {
  if (!status) return 'Submitted';
  const s = String(status).trim();
  const lower = s.toLowerCase();
  if (lower === 'reported' || lower === 'submitted' || lower === 'new') return 'Submitted';
  if (lower === 'under review' || lower === 'pending') return 'Under Review';
  if (lower === 'assigned') return 'Assigned';
  if (lower === 'in progress' || lower === 'in_progress') return 'In Progress';
  if (lower === 'resolved' || lower === 'closed' || lower === 'fixed') return 'Resolved';
  if (lower === 'rejected' || lower === 'cancelled') return 'Rejected';
  return TICKET_STATUSES.includes(s) ? s : 'Submitted';
}

/**
 * Normalizes urgency levels
 */
function normalizeUrgency(urgency) {
  if (!urgency) return 'Standard';
  const u = String(urgency).trim().toLowerCase();
  if (u.includes('emergency') || u.includes('critical') || u.includes('hazard')) return 'Emergency Hazard';
  if (u.includes('high')) return 'High Priority';
  if (u.includes('medium') || u.includes('standard') || u.includes('normal') || u.includes('low')) return 'Standard';
  return 'Standard';
}

/**
 * Normalizes issue types
 */
function normalizeIssueType(issue) {
  if (!issue) return 'Completely Off';
  const i = String(issue).trim().toLowerCase();
  if (i.includes('blackout') || i.includes('completely off') || i.includes('bulb off') || i.includes('zero current')) return 'Completely Off';
  if (i.includes('flicker') || i.includes('strobe') || i.includes('surge')) return 'Flickering';
  if (i.includes('wire') || i.includes('hazard') || i.includes('shock') || i.includes('cable') || i.includes('tamper')) return 'Wire Hazard';
  if (i.includes('day') || i.includes('ldr') || i.includes('waste')) return 'Day-Burning';
  if (i.includes('broken') || i.includes('fixture') || i.includes('glass') || i.includes('pole damage') || i.includes('damage')) return 'Broken Fixture';
  if (i.includes('dim') || i.includes('low')) return 'Dim Illumination';
  return issue;
}

/**
 * Normalizes campus location to one of the 7 defined campus zones
 */
function normalizeCampusLocation(loc) {
  if (!loc) return 'Main College Building';
  const l = String(loc).trim().toLowerCase();
  if (l.includes('entrance') || l.includes('gate') || l.includes('arch') || l.includes('security')) return 'College Entrance';
  if (l.includes('road') || l.includes('avenue') || l.includes('street') || l.includes('loop')) return 'Campus Roads';
  if (l.includes('park') || l.includes('vehicle') || l.includes('car') || l.includes('bike')) return 'Parking Area';
  if (l.includes('hostel') || l.includes('mess') || l.includes('quarters') || l.includes('dorm')) return 'Hostel Area';
  if (l.includes('play') || l.includes('ground') || l.includes('sport') || l.includes('court') || l.includes('turf') || l.includes('gym')) return 'Playground';
  if (l.includes('lib') || l.includes('book') || l.includes('read')) return 'Library Area';
  if (l.includes('main') || l.includes('building') || l.includes('admin') || l.includes('block') || l.includes('academic') || l.includes('central')) return 'Main College Building';
  return CAMPUS_LOCATIONS.includes(loc) ? loc : 'Main College Building';
}

/**
 * Validates a Ticket object
 */
function validateTicket(ticket) {
  const errors = [];

  if (!ticket._id || typeof ticket._id !== 'string') {
    errors.push('Ticket _id must be a non-empty string (e.g. YIT-2026-1042).');
  }

  if (!ticket.location || ticket.location.type !== 'Point' || !Array.isArray(ticket.location.coordinates) || ticket.location.coordinates.length !== 2) {
    errors.push('Ticket location must be GeoJSON Point { type: "Point", coordinates: [lng, lat] }.');
  } else {
    const [lng, lat] = ticket.location.coordinates;
    if (typeof lng !== 'number' || typeof lat !== 'number' || isNaN(lng) || isNaN(lat)) {
      errors.push('Ticket location coordinates must be valid numbers [longitude, latitude].');
    }
  }

  if (!ticket.wardZone && !ticket.campusLocation) {
    errors.push('Campus location is required.');
  }

  if (!ticket.address || typeof ticket.address !== 'string') {
    errors.push('Ticket campus landmark or location address is required.');
  }

  if (!ticket.issueType || typeof ticket.issueType !== 'string') {
    errors.push('Ticket issueType is required.');
  }

  if (!ticket.urgencyLevel || !URGENCY_LEVELS.includes(ticket.urgencyLevel)) {
    errors.push(`Ticket urgencyLevel must be one of: ${URGENCY_LEVELS.join(', ')}.`);
  }

  if (!ticket.reporter || typeof ticket.reporter !== 'object') {
    errors.push('Ticket reporter must be an object with fullName and mobileNumber.');
  } else {
    if (!ticket.reporter.fullName) errors.push('Ticket reporter fullName is required.');
    if (!ticket.reporter.mobileNumber) errors.push('Ticket reporter mobileNumber is required.');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

/**
 * Creates and formats a Ticket object adhering to the Ticket Model
 */
function createTicket(data = {}) {
  const now = new Date().toISOString();

  // Handle coordinates: YIT Moodbidri campus default (13.0665, 74.9953)
  let lng = 74.9953;
  let lat = 13.0665;
  if (data.location && Array.isArray(data.location.coordinates) && data.location.coordinates.length === 2) {
    lng = parseFloat(data.location.coordinates[0]);
    lat = parseFloat(data.location.coordinates[1]);
  } else if (data.lng !== undefined && data.lat !== undefined) {
    lng = parseFloat(data.lng);
    lat = parseFloat(data.lat);
  }

  // Handle Ticket ID
  let id = data._id || data.ticketId;
  if (!id) {
    const randNum = Math.floor(1000 + Math.random() * 9000);
    id = `YIT-2026-${randNum}`;
  }

  const campusLocation = normalizeCampusLocation(data.campusLocation || data.wardZone || data.ward);

  // Handle Reporter
  const reporterRaw = data.reporter || {};
  const reporter = {
    fullName: reporterRaw.fullName || data.citizenName || "Anonymous Reporter",
    role: reporterRaw.role || data.reporterRole || "Student", // "Student", "Staff/Faculty", "Visitor"
    idNumber: reporterRaw.idNumber || data.usn || data.idNumber || reporterRaw.usn || "DEMO-STUDENT", // USN or Employee ID
    mobileNumber: reporterRaw.mobileNumber || data.citizenPhone || "+91 98450 12345",
    email: reporterRaw.email || data.email || (reporterRaw.idNumber ? `${reporterRaw.idNumber.toLowerCase()}@example.invalid` : "student@example.invalid"),
    department: reporterRaw.department || data.department || "Computer Science & Engineering"
  };

  const status = normalizeStatus(data.status);
  const urgencyLevel = normalizeUrgency(data.urgencyLevel || data.priority);
  const issueType = normalizeIssueType(data.issueType);

  const ticket = {
    _id: id,
    ticketId: id,
    location: {
      type: "Point",
      coordinates: [lng, lat]
    },
    campusLocation: campusLocation,
    wardZone: campusLocation, // Alias for backward compatibility
    poleId: data.poleId || null,
    poleCode: data.poleCode || (data.poleId ? String(data.poleId) : 'YIT-GEN'),
    address: data.address || `${campusLocation}, YIT Campus, Moodbidri`,
    issueType: issueType,
    urgencyLevel: urgencyLevel,
    priority: urgencyLevel, // Alias
    description: data.description || "Reported campus streetlight fault.",
    photoUrl: data.photoUrl || null,
    reporter: reporter,
    ownerUserId: data.ownerUserId || null,
    citizenName: reporter.fullName, // Backward compatibility
    citizenPhone: reporter.mobileNumber, // Backward compatibility
    status: status,
    assignedTechnicianId: data.assignedTechnicianId || data.assignedTechId || null,
    assignedTechId: data.assignedTechnicianId || data.assignedTechId || null,
    assignedTechName: data.assignedTechName || null,
    createdAt: data.createdAt || now,
    updatedAt: data.updatedAt || now,
    resolvedAt: data.resolvedAt || null,
    repairNotes: data.repairNotes || "",
    resolutionPhoto: data.resolutionPhoto || null,
    rating: data.rating || null,
    feedback: data.feedback || null,
    ratedAt: data.ratedAt || null,
    source: data.source || "YIT Campus Portal",
    history: Array.isArray(data.history) && data.history.length > 0 ? data.history : [
      {
        status: status,
        timestamp: data.createdAt || now,
        note: `Fault report registered by ${reporter.fullName} (${reporter.role} - ${reporter.idNumber}).`,
        by: reporter.fullName
      }
    ]
  };

  return ticket;
}

module.exports = {
  CAMPUS_LOCATIONS,
  TICKET_STATUSES,
  URGENCY_LEVELS,
  ISSUE_TYPES,
  normalizeStatus,
  normalizeUrgency,
  normalizeIssueType,
  normalizeCampusLocation,
  validateTicket,
  createTicket
};
