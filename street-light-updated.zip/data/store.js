const fs = require('fs');
const path = require('path');
const TicketModel = require('../models/Ticket');

const DB_FILE = path.join(__dirname, 'db.json');

// Yenepoya Institute of Technology (YIT), Moodbidri
// Geographic Center: 13.0665, 74.9953 (Thodar, Moodbidri, Mangalore)

const initialData = {
  poles: [
    // 1. Main College Building
    {
      id: "POL-YIT-101",
      code: "YIT-MCB-01",
      street: "Main College Building - Admin Block Portico",
      ward: "Main College Building",
      campusLocation: "Main College Building",
      lat: 13.0668,
      lng: 74.9951,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-ADMIN"
    },
    {
      id: "POL-YIT-102",
      code: "YIT-MCB-02",
      street: "Main College Building - CSE & ISE Academic Wing",
      ward: "Main College Building",
      campusLocation: "Main College Building",
      lat: 13.0671,
      lng: 74.9953,
      type: "LED 90W Smart",
      status: "faulty",
      wattage: 90,
      installedYear: 2023,
      circuitId: "YIT-CKT-ADMIN"
    },
    {
      id: "POL-YIT-103",
      code: "YIT-MCB-03",
      street: "Main College Building - Central Quadrangle & Auditorium",
      ward: "Main College Building",
      campusLocation: "Main College Building",
      lat: 13.0666,
      lng: 74.9949,
      type: "LED 70W Standard",
      status: "active",
      wattage: 70,
      installedYear: 2024,
      circuitId: "YIT-CKT-ADMIN"
    },
    {
      id: "POL-YIT-104",
      code: "YIT-MCB-04",
      street: "Main College Building - Mechanical & Civil Lab Block",
      ward: "Main College Building",
      campusLocation: "Main College Building",
      lat: 13.0673,
      lng: 74.9955,
      type: "Solar LED 80W",
      status: "active",
      wattage: 80,
      installedYear: 2023,
      circuitId: "YIT-CKT-LABS"
    },

    // 2. College Entrance
    {
      id: "POL-YIT-201",
      code: "YIT-ENT-01",
      street: "College Entrance - Main Arch Gate & Security Post",
      ward: "College Entrance",
      campusLocation: "College Entrance",
      lat: 13.0658,
      lng: 74.9945,
      type: "LED 120W High-Mast",
      status: "active",
      wattage: 120,
      installedYear: 2023,
      circuitId: "YIT-CKT-GATE"
    },
    {
      id: "POL-YIT-202",
      code: "YIT-ENT-02",
      street: "College Entrance - Reception & Visitor Security Cabin",
      ward: "College Entrance",
      campusLocation: "College Entrance",
      lat: 13.0660,
      lng: 74.9947,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-GATE"
    },
    {
      id: "POL-YIT-203",
      code: "YIT-ENT-03",
      street: "College Entrance - Campus Bus Bay & Pick-up Shelter",
      ward: "College Entrance",
      campusLocation: "College Entrance",
      lat: 13.0656,
      lng: 74.9943,
      type: "LED 90W Smart",
      status: "faulty",
      wattage: 90,
      installedYear: 2022,
      circuitId: "YIT-CKT-GATE"
    },

    // 3. Campus Roads
    {
      id: "POL-YIT-301",
      code: "YIT-CRD-01",
      street: "Campus Roads - Main Academic Boulevard, Pillar 3",
      ward: "Campus Roads",
      campusLocation: "Campus Roads",
      lat: 13.0663,
      lng: 74.9950,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-ROADS"
    },
    {
      id: "POL-YIT-302",
      code: "YIT-CRD-02",
      street: "Campus Roads - Engineering Loop Road, Curve 2",
      ward: "Campus Roads",
      campusLocation: "Campus Roads",
      lat: 13.0669,
      lng: 74.9958,
      type: "LED 70W Standard",
      status: "in_repair",
      wattage: 70,
      installedYear: 2023,
      circuitId: "YIT-CKT-ROADS"
    },
    {
      id: "POL-YIT-303",
      code: "YIT-CRD-03",
      street: "Campus Roads - South Ring Road Near Cafeteria",
      ward: "Campus Roads",
      campusLocation: "Campus Roads",
      lat: 13.0660,
      lng: 74.9956,
      type: "Solar LED 80W",
      status: "active",
      wattage: 80,
      installedYear: 2024,
      circuitId: "YIT-CKT-ROADS"
    },
    {
      id: "POL-YIT-304",
      code: "YIT-CRD-04",
      street: "Campus Roads - Inter-department Link Avenue",
      ward: "Campus Roads",
      campusLocation: "Campus Roads",
      lat: 13.0675,
      lng: 74.9951,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2022,
      circuitId: "YIT-CKT-ROADS"
    },

    // 4. Parking Area
    {
      id: "POL-YIT-401",
      code: "YIT-PRK-01",
      street: "Parking Area - Student Two-Wheeler Shed Zone A",
      ward: "Parking Area",
      campusLocation: "Parking Area",
      lat: 13.0659,
      lng: 74.9952,
      type: "LED 70W Standard",
      status: "active",
      wattage: 70,
      installedYear: 2023,
      circuitId: "YIT-CKT-PARK"
    },
    {
      id: "POL-YIT-402",
      code: "YIT-PRK-02",
      street: "Parking Area - Faculty & Staff Car Parking Pavilion",
      ward: "Parking Area",
      campusLocation: "Parking Area",
      lat: 13.0662,
      lng: 74.9946,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-PARK"
    },
    {
      id: "POL-YIT-403",
      code: "YIT-PRK-03",
      street: "Parking Area - College Bus Terminal & Transit Zone",
      ward: "Parking Area",
      campusLocation: "Parking Area",
      lat: 13.0657,
      lng: 74.9949,
      type: "LED 120W High-Mast",
      status: "faulty",
      wattage: 120,
      installedYear: 2022,
      circuitId: "YIT-CKT-PARK"
    },

    // 5. Hostel Area
    {
      id: "POL-YIT-501",
      code: "YIT-HST-01",
      street: "Hostel Area - Boys Hostel (Kaveri Block) Entrance",
      ward: "Hostel Area",
      campusLocation: "Hostel Area",
      lat: 13.0676,
      lng: 74.9962,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-HOSTEL"
    },
    {
      id: "POL-YIT-502",
      code: "YIT-HST-02",
      street: "Hostel Area - Girls Hostel (Netravati Block) Pathway",
      ward: "Hostel Area",
      campusLocation: "Hostel Area",
      lat: 13.0679,
      lng: 74.9959,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-HOSTEL"
    },
    {
      id: "POL-YIT-503",
      code: "YIT-HST-03",
      street: "Hostel Area - Central Mess & Dining Hall Courtyard",
      ward: "Hostel Area",
      campusLocation: "Hostel Area",
      lat: 13.0674,
      lng: 74.9965,
      type: "Solar LED 80W",
      status: "in_repair",
      wattage: 80,
      installedYear: 2023,
      circuitId: "YIT-CKT-HOSTEL"
    },
    {
      id: "POL-YIT-504",
      code: "YIT-HST-04",
      street: "Hostel Area - Staff Quarters & Residence Lane",
      ward: "Hostel Area",
      campusLocation: "Hostel Area",
      lat: 13.0681,
      lng: 74.9966,
      type: "LED 70W Standard",
      status: "active",
      wattage: 70,
      installedYear: 2022,
      circuitId: "YIT-CKT-HOSTEL"
    },

    // 6. Playground
    {
      id: "POL-YIT-601",
      code: "YIT-PLY-01",
      street: "Playground - Main Cricket & Athletic Turf Tower 1",
      ward: "Playground",
      campusLocation: "Playground",
      lat: 13.0654,
      lng: 74.9960,
      type: "LED 150W High-Mast",
      status: "active",
      wattage: 150,
      installedYear: 2023,
      circuitId: "YIT-CKT-SPORTS"
    },
    {
      id: "POL-YIT-602",
      code: "YIT-PLY-02",
      street: "Playground - Basketball & Badminton Court Floodlight",
      ward: "Playground",
      campusLocation: "Playground",
      lat: 13.0652,
      lng: 74.9957,
      type: "LED 120W High-Mast",
      status: "active",
      wattage: 120,
      installedYear: 2023,
      circuitId: "YIT-CKT-SPORTS"
    },
    {
      id: "POL-YIT-603",
      code: "YIT-PLY-03",
      street: "Playground - Gymnasium & Sports Pavilion Perimeter",
      ward: "Playground",
      campusLocation: "Playground",
      lat: 13.0656,
      lng: 74.9963,
      type: "LED 90W Smart",
      status: "faulty",
      wattage: 90,
      installedYear: 2022,
      circuitId: "YIT-CKT-SPORTS"
    },

    // 7. Library Area
    {
      id: "POL-YIT-701",
      code: "YIT-LIB-01",
      street: "Library Area - Central Library Front Plaza",
      ward: "Library Area",
      campusLocation: "Library Area",
      lat: 13.0664,
      lng: 74.9954,
      type: "LED 90W Smart",
      status: "active",
      wattage: 90,
      installedYear: 2024,
      circuitId: "YIT-CKT-LIB"
    },
    {
      id: "POL-YIT-702",
      code: "YIT-LIB-02",
      street: "Library Area - Digital Learning & Resource Center",
      ward: "Library Area",
      campusLocation: "Library Area",
      lat: 13.0665,
      lng: 74.9957,
      type: "Solar LED 80W",
      status: "active",
      wattage: 80,
      installedYear: 2023,
      circuitId: "YIT-CKT-LIB"
    },
    {
      id: "POL-YIT-703",
      code: "YIT-LIB-03",
      street: "Library Area - Reading Garden & Amphitheater Pathway",
      ward: "Library Area",
      campusLocation: "Library Area",
      lat: 13.0667,
      lng: 74.9956,
      type: "LED 70W Standard",
      status: "active",
      wattage: 70,
      installedYear: 2024,
      circuitId: "YIT-CKT-LIB"
    }
  ],

  technicians: [
    {
      id: "TECH-YIT-01",
      name: "Campus Technician 1",
      designation: "Senior Campus Electrician",
      phone: "Not provided",
      ward: "Main College Building",
      campusLocation: "Main College Building",
      skills: ["Academic Block Wiring", "High-Mast Floodlights", "LED Driver Repair"],
      status: "Available"
    },
    {
      id: "TECH-YIT-02",
      name: "Campus Technician 2",
      designation: "Electrical Maintenance Supervisor",
      phone: "Not provided",
      ward: "Playground",
      campusLocation: "Playground",
      skills: ["Underground Power Cables", "Substation Transformers", "Emergency Wire Hazards"],
      status: "On Field"
    },
    {
      id: "TECH-YIT-03",
      name: "Campus Technician 3",
      designation: "Solar & Smart Lighting Tech",
      phone: "Not provided",
      ward: "Hostel Area",
      campusLocation: "Hostel Area",
      skills: ["Solar Streetlights", "Photocell Sensors", "Timer Switches"],
      status: "Available"
    },
    {
      id: "TECH-YIT-04",
      name: "Campus Technician 4",
      designation: "Campus Facilities Technician",
      phone: "Not provided",
      ward: "College Entrance",
      campusLocation: "College Entrance",
      skills: ["Pole Structural Safety", "Cable Realignment", "Roadway Illumination"],
      status: "Available"
    }
  ],

  complaints: [
    {
      _id: "YIT-2026-1042",
      ticketId: "YIT-2026-1042",
      location: {
        type: "Point",
        coordinates: [74.9953, 13.0671]
      },
      campusLocation: "Main College Building",
      wardZone: "Main College Building",
      poleId: "POL-YIT-102",
      poleCode: "YIT-MCB-02",
      address: "Main College Building - CSE & ISE Academic Wing, 2nd Floor Corridor Junction",
      issueType: "Flickering",
      urgencyLevel: "High Priority",
      priority: "High Priority",
      description: "Streetlight fixture is blinking rapidly like a strobe light outside the CSE lab entrance. Disturbing evening lab sessions and pedestrian corridor.",
      photoUrl: null,
      reporter: {
        fullName: "Demo Student 1",
        role: "Student",
        idNumber: "DEMO-STUDENT-01",
        mobileNumber: "Not provided",
        email: "student1@example.invalid",
        department: "Computer Science & Engineering"
      },
      citizenName: "Demo Student 1",
      citizenPhone: "Not provided",
      status: "Assigned",
      assignedTechnicianId: "TECH-YIT-01",
      assignedTechId: "TECH-YIT-01",
      assignedTechName: "Campus Technician 1",
      createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      resolvedAt: null,
      repairNotes: "Dispatched with spare 90W constant-current LED driver module.",
      resolutionPhoto: null,
      source: "YIT Student Portal",
      history: [
        {
          status: "Submitted",
          timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
          note: "Grievance submitted by student Demo Student 1 (USN: DEMO-STUDENT-01).",
          by: "Demo Student 1"
        },
        {
          status: "Assigned",
          timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
          note: "Assigned to Senior Campus Electrician Campus Technician 1 (Not provided).",
          by: "Campus Maintenance Dept"
        }
      ]
    },
    {
      _id: "YIT-2026-1039",
      ticketId: "YIT-2026-1039",
      location: {
        type: "Point",
        coordinates: [74.9963, 13.0656]
      },
      campusLocation: "Playground",
      wardZone: "Playground",
      poleId: "POL-YIT-603",
      poleCode: "YIT-PLY-03",
      address: "Playground - Gymnasium & Sports Pavilion Perimeter",
      issueType: "Wire Hazard",
      urgencyLevel: "Emergency Hazard",
      priority: "Emergency Hazard",
      description: "Severe hazard: Base access panel door is broken open with live 230V wiring exposed near the student pavilion steps. High shock risk during evening games.",
      photoUrl: null,
      reporter: {
        fullName: "Demo Faculty Member",
        role: "Staff/Faculty",
        idNumber: "DEMO-FACULTY-01",
        mobileNumber: "Not provided",
        email: "faculty@example.invalid",
        department: "Electronics & Communication Engg"
      },
      citizenName: "Demo Faculty Member",
      citizenPhone: "Not provided",
      status: "In Progress",
      assignedTechnicianId: "TECH-YIT-02",
      assignedTechId: "TECH-YIT-02",
      assignedTechName: "Campus Technician 2",
      createdAt: new Date(Date.now() - 3600000 * 14).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 1).toISOString(),
      resolvedAt: null,
      repairNotes: "Technician isolated pole breaker at panel board. Replacing inspection cover and installing new IP65 tamper-proof lock.",
      resolutionPhoto: null,
      source: "YIT Faculty Grievance Desk",
      history: [
        {
          status: "Submitted",
          timestamp: new Date(Date.now() - 3600000 * 14).toISOString(),
          note: "Reported by Demo Faculty Member (Dept of ECE).",
          by: "Demo Faculty Member"
        },
        {
          status: "Under Review",
          timestamp: new Date(Date.now() - 3600000 * 13).toISOString(),
          note: "Flagged as Critical Safety Hazard by Estates Officer.",
          by: "Estates & Facilities Office"
        },
        {
          status: "Assigned",
          timestamp: new Date(Date.now() - 3600000 * 10).toISOString(),
          note: "Assigned to Electrical Supervisor Campus Technician 2.",
          by: "Campus Maintenance Dept"
        },
        {
          status: "In Progress",
          timestamp: new Date(Date.now() - 3600000 * 1).toISOString(),
          note: "Technician arrived on-site with caution barrier cones and replacement cover.",
          by: "Campus Technician 2"
        }
      ]
    },
    {
      _id: "YIT-2026-1030",
      ticketId: "YIT-2026-1030",
      location: {
        type: "Point",
        coordinates: [74.9949, 13.0657]
      },
      campusLocation: "Parking Area",
      wardZone: "Parking Area",
      poleId: "POL-YIT-403",
      poleCode: "YIT-PRK-03",
      address: "Parking Area - College Bus Terminal & Transit Zone",
      issueType: "Day-Burning",
      urgencyLevel: "Standard",
      priority: "Standard",
      description: "Photocell twilight sensor stuck closed. The 120W High-Mast continues to burn under bright afternoon sunlight, causing substantial electricity wastage.",
      photoUrl: null,
      reporter: {
        fullName: "Demo Student 2",
        role: "Student",
        idNumber: "DEMO-STUDENT-02",
        mobileNumber: "Not provided",
        email: "student2@example.invalid",
        department: "Information Science & Engineering"
      },
      citizenName: "Demo Student 2",
      citizenPhone: "Not provided",
      status: "Under Review",
      assignedTechnicianId: null,
      assignedTechId: null,
      assignedTechName: null,
      createdAt: new Date(Date.now() - 3600000 * 20).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
      resolvedAt: null,
      repairNotes: "",
      resolutionPhoto: null,
      source: "YIT Green Campus Initiative",
      history: [
        {
          status: "Submitted",
          timestamp: new Date(Date.now() - 3600000 * 20).toISOString(),
          note: "Reported by student Demo Student 2 (USN: DEMO-STUDENT-02).",
          by: "Demo Student 2"
        },
        {
          status: "Under Review",
          timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
          note: "Energy wastage verified via campus smart meter telemetry.",
          by: "Campus Maintenance Dept"
        }
      ]
    },
    {
      _id: "YIT-2026-1025",
      ticketId: "YIT-2026-1025",
      location: {
        type: "Point",
        coordinates: [74.9943, 13.0656]
      },
      campusLocation: "College Entrance",
      wardZone: "College Entrance",
      poleId: "POL-YIT-203",
      poleCode: "YIT-ENT-03",
      address: "College Entrance - Campus Bus Bay & Pick-up Shelter",
      issueType: "Completely Off",
      urgencyLevel: "High Priority",
      priority: "High Priority",
      description: "Streetlight is completely dead since yesterday. Students waiting for evening Moodbidri/Mangalore route buses are in complete darkness.",
      photoUrl: null,
      reporter: {
        fullName: "Demo Staff Member",
        role: "Staff/Faculty",
        idNumber: "DEMO-STAFF-01",
        mobileNumber: "Not provided",
        email: "staff@example.invalid",
        department: "Campus Security Division"
      },
      citizenName: "Demo Staff Member",
      citizenPhone: "Not provided",
      status: "Submitted",
      assignedTechnicianId: null,
      assignedTechId: null,
      assignedTechName: null,
      createdAt: new Date(Date.now() - 3600000 * 26).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 26).toISOString(),
      resolvedAt: null,
      repairNotes: "",
      resolutionPhoto: null,
      source: "Campus Security Desk",
      history: [
        {
          status: "Submitted",
          timestamp: new Date(Date.now() - 3600000 * 26).toISOString(),
          note: "Reported by Security Officer Demo Staff Member.",
          by: "Demo Staff Member"
        }
      ]
    },
    {
      _id: "YIT-2026-1015",
      ticketId: "YIT-2026-1015",
      location: {
        type: "Point",
        coordinates: [74.9956, 13.0667]
      },
      campusLocation: "Library Area",
      wardZone: "Library Area",
      poleId: "POL-YIT-703",
      poleCode: "YIT-LIB-03",
      address: "Library Area - Reading Garden & Amphitheater Pathway",
      issueType: "Broken Fixture",
      urgencyLevel: "Standard",
      priority: "Standard",
      description: "Polycarbonate casing fractured during monsoon thunderstorm, letting rainwater seep into the LED array.",
      photoUrl: null,
      reporter: {
        fullName: "Demo Student 3",
        role: "Student",
        idNumber: "DEMO-STUDENT-03",
        mobileNumber: "Not provided",
        email: "student3@example.invalid",
        department: "Electronics & Communication Engg"
      },
      citizenName: "Demo Student 3",
      citizenPhone: "Not provided",
      status: "Resolved",
      assignedTechnicianId: "TECH-YIT-03",
      assignedTechId: "TECH-YIT-03",
      assignedTechName: "Campus Technician 3",
      createdAt: new Date(Date.now() - 3600000 * 72).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 40).toISOString(),
      resolvedAt: new Date(Date.now() - 3600000 * 40).toISOString(),
      repairNotes: "Replaced 70W luminaire housing with new IP66 die-cast unit. All connections weather-sealed and illumination verified.",
      resolutionPhoto: null,
      rating: 5,
      feedback: "Prompt repair within 24 hours. The reading garden pathway is well illuminated now!",
      ratedAt: new Date(Date.now() - 3600000 * 30).toISOString(),
      source: "YIT Student Portal",
      history: [
        {
          status: "Submitted",
          timestamp: new Date(Date.now() - 3600000 * 72).toISOString(),
          note: "Reported by student Demo Student 3 (USN: DEMO-STUDENT-03).",
          by: "Demo Student 3"
        },
        {
          status: "Assigned",
          timestamp: new Date(Date.now() - 3600000 * 55).toISOString(),
          note: "Assigned to Solar & Smart Lighting Tech Campus Technician 3.",
          by: "Campus Maintenance Dept"
        },
        {
          status: "In Progress",
          timestamp: new Date(Date.now() - 3600000 * 48).toISOString(),
          note: "Field electrician mounted ladder and unbolted broken fixture.",
          by: "Campus Technician 3"
        },
        {
          status: "Resolved",
          timestamp: new Date(Date.now() - 3600000 * 40).toISOString(),
          note: "New IP66 fixture installed and illuminated. Verified by Estates Inspector.",
          by: "Campus Technician 3"
        },
        {
          status: "Feedback Received",
          timestamp: new Date(Date.now() - 3600000 * 30).toISOString(),
          note: "Student rated repair 5/5 stars: 'Prompt repair within 24 hours. The reading garden pathway is well illuminated now!'",
          by: "Demo Student 3"
        }
      ]
    }
  ],

  notifications: [
    {
      id: "NOTIF-101",
      title: "Work Order Assigned",
      message: "Ticket YIT-2026-1042 (Main College Building) has been assigned to Campus Technician 1.",
      category: "assignment",
      time: new Date(Date.now() - 3600000 * 2).toISOString(),
      read: false,
      ticketId: "YIT-2026-1042"
    },
    {
      id: "NOTIF-102",
      title: "Critical Safety Alert",
      message: "Emergency wire hazard reported at Playground near sports pavilion. Technician dispatched.",
      category: "hazard",
      time: new Date(Date.now() - 3600000 * 10).toISOString(),
      read: false,
      ticketId: "YIT-2026-1039"
    },
    {
      id: "NOTIF-103",
      title: "Repair Restored & Verified",
      message: "Streetlight fault YIT-2026-1015 at Library Area successfully resolved and verified.",
      category: "resolved",
      time: new Date(Date.now() - 3600000 * 40).toISOString(),
      read: true,
      ticketId: "YIT-2026-1015"
    },
    {
      id: "NOTIF-104",
      title: "Monthly Campus Audit Completed",
      message: "Campus Estates & Maintenance Division published the October 2026 Street Light Efficiency Report.",
      category: "audit",
      time: new Date(Date.now() - 3600000 * 120).toISOString(),
      read: true,
      ticketId: null
    }
  ]
};

function initDB(forceReset = false) {
  if (!fs.existsSync(DB_FILE) || forceReset) {
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf8');
  }
}

function readDB() {
  initDB();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const data = JSON.parse(raw);

    // If database still contains old non-campus poles (e.g. Bangalore coordinates or MG Road), migrate to YIT data
    const hasOldBangaloreData = data.poles && data.poles.some(p => p.ward && p.ward.includes('Ward 1 - Central'));
    if (hasOldBangaloreData || !data.poles || data.poles.length === 0) {
      console.log('Migrating database to Yenepoya Institute of Technology (YIT) Moodbidri campus dataset...');
      fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf8');
      return initialData;
    }

    if (!data.notifications) {
      data.notifications = initialData.notifications;
    }

    return data;
  } catch (err) {
    console.error('Error reading db.json:', err);
    return initialData;
  }
}

function writeDB(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing db.json:', err);
    return false;
  }
}

// Poles operations
function getPoles() {
  const db = readDB();
  return db.poles || [];
}

function getPoleById(id) {
  const db = readDB();
  return (db.poles || []).find(p => p.id === id || p.code === id);
}

function addPole(poleData) {
  const db = readDB();
  const campusLocation = TicketModel.normalizeCampusLocation(poleData.campusLocation || poleData.ward);
  const nextNum = (db.poles || []).length + 101;
  const newPole = {
    id: `POL-YIT-${nextNum}`,
    code: poleData.code || `YIT-${campusLocation.substring(0, 3).toUpperCase()}-${nextNum}`,
    street: poleData.street || `${campusLocation} - New Campus Lighting Pole`,
    ward: campusLocation,
    campusLocation: campusLocation,
    lat: parseFloat(poleData.lat) || 13.0665,
    lng: parseFloat(poleData.lng) || 74.9953,
    type: poleData.type || "LED 90W Smart",
    status: poleData.status || "active",
    wattage: parseInt(poleData.wattage) || 90,
    installedYear: new Date().getFullYear(),
    circuitId: poleData.circuitId || "YIT-CKT-NEW"
  };
  db.poles.push(newPole);
  writeDB(db);
  return newPole;
}

function updatePole(id, updates) {
  const db = readDB();
  const pole = db.poles.find(p => p.id === id || p.code === id);
  if (!pole) return null;
  Object.assign(pole, updates);
  writeDB(db);
  return pole;
}

// Technicians operations
function getTechnicians() {
  const db = readDB();
  return db.technicians || [];
}

// Complaints / Tickets operations
function getComplaints(filter = {}) {
  const db = readDB();
  let list = (db.complaints || []).map(c => TicketModel.createTicket(c));

  if (filter.status && filter.status !== 'All') {
    const s = TicketModel.normalizeStatus(filter.status).toLowerCase();
    list = list.filter(c => c.status.toLowerCase() === s);
  }
  if (filter.campusLocation || filter.wardZone || filter.ward) {
    const loc = filter.campusLocation || filter.wardZone || filter.ward;
    if (loc !== 'All') {
      const normLoc = TicketModel.normalizeCampusLocation(loc);
      list = list.filter(c => c.campusLocation === normLoc || c.wardZone === normLoc);
    }
  }
  if (filter.urgencyLevel || filter.priority) {
    const p = filter.urgencyLevel || filter.priority;
    if (p !== 'All') {
      const normU = TicketModel.normalizeUrgency(p).toLowerCase();
      list = list.filter(c => c.urgencyLevel.toLowerCase() === normU || (c.priority && c.priority.toLowerCase() === normU));
    }
  }
  if (filter.reporterId || filter.usn) {
    const qId = String(filter.reporterId || filter.usn).trim().toLowerCase();
    list = list.filter(c => {
      const id = (c.reporter?.idNumber || '').toLowerCase();
      return id === qId;
    });
  }
  if (filter.search) {
    const q = filter.search.toLowerCase();
    list = list.filter(c => 
      (c._id && c._id.toLowerCase().includes(q)) ||
      (c.ticketId && c.ticketId.toLowerCase().includes(q)) ||
      (c.poleId && c.poleId.toLowerCase().includes(q)) ||
      (c.poleCode && c.poleCode.toLowerCase().includes(q)) ||
      (c.campusLocation && c.campusLocation.toLowerCase().includes(q)) ||
      (c.address && c.address.toLowerCase().includes(q)) ||
      (c.description && c.description.toLowerCase().includes(q)) ||
      (c.reporter?.mobileNumber && c.reporter.mobileNumber.toLowerCase().includes(q)) ||
      (c.reporter?.fullName && c.reporter.fullName.toLowerCase().includes(q)) ||
      (c.reporter?.idNumber && c.reporter.idNumber.toLowerCase().includes(q)) ||
      (c.citizenPhone && c.citizenPhone.toLowerCase().includes(q)) ||
      (c.citizenName && c.citizenName.toLowerCase().includes(q))
    );
  }

  // Sort newest first
  return list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function getComplaintByTicket(query) {
  if (!query) return null;
  const db = readDB();
  const q = String(query).trim().toUpperCase();
  const raw = (db.complaints || []).find(c => {
    const id = (c._id || c.ticketId || '').toUpperCase();
    const usn = (c.reporter?.idNumber || '').toUpperCase();
    const phone = (c.reporter?.mobileNumber || c.citizenPhone || '').replace(/\D/g, '');
    const cleanQ = String(query).replace(/\D/g, '');
    return id === q || usn === q || (cleanQ.length >= 6 && phone.endsWith(cleanQ));
  });
  return raw ? TicketModel.createTicket(raw) : null;
}

function createComplaint(data) {
  const db = readDB();

  // Find linked pole if specified
  const pole = data.poleId ? db.poles.find(p => p.id === data.poleId || p.code === data.poleId) : null;
  const poleCode = pole ? pole.code : (data.poleCode || (data.poleId ? String(data.poleId) : 'YIT-GEN'));
  const campusLocation = TicketModel.normalizeCampusLocation(data.campusLocation || data.wardZone || data.ward || (pole ? pole.campusLocation : 'Main College Building'));

  // Ensure lat / lng coordinates around YIT campus
  let lat = 13.0665;
  let lng = 74.9953;
  if (data.location && Array.isArray(data.location.coordinates) && data.location.coordinates.length === 2) {
    lng = parseFloat(data.location.coordinates[0]);
    lat = parseFloat(data.location.coordinates[1]);
  } else if (data.lat !== undefined && data.lng !== undefined) {
    lat = parseFloat(data.lat);
    lng = parseFloat(data.lng);
  } else if (pole) {
    lat = pole.lat;
    lng = pole.lng;
  }

  const randNum = Math.floor(1000 + Math.random() * 9000);
  const ticketId = data._id || data.ticketId || `YIT-2026-${randNum}`;

  const rawTicket = {
    _id: ticketId,
    ticketId: ticketId,
    location: {
      type: "Point",
      coordinates: [lng, lat]
    },
    campusLocation: campusLocation,
    wardZone: campusLocation,
    poleId: pole ? pole.id : (data.poleId || null),
    poleCode: poleCode,
    address: data.address || (pole ? pole.street : `${campusLocation}, YIT Campus, Moodbidri`),
    issueType: data.issueType || "Completely Off",
    urgencyLevel: data.urgencyLevel || data.priority || "High Priority",
    priority: data.urgencyLevel || data.priority || "High Priority",
    description: data.description || "Reported campus streetlight fault.",
    photoUrl: data.photoUrl || null,
    ownerUserId: data.ownerUserId || null,
    reporter: {
      fullName: (data.reporter && data.reporter.fullName) || data.citizenName || "Campus Student / Staff",
      role: (data.reporter && data.reporter.role) || data.reporterRole || "Student",
      idNumber: (data.reporter && data.reporter.idNumber) || data.usn || data.idNumber || "DEMO-STUDENT",
      mobileNumber: (data.reporter && data.reporter.mobileNumber) || data.citizenPhone || "Not provided",
      email: (data.reporter && data.reporter.email) || data.email || "student@example.invalid",
      department: (data.reporter && data.reporter.department) || data.department || "Engineering Department"
    },
    citizenName: (data.reporter && data.reporter.fullName) || data.citizenName || "Campus Student / Staff",
    citizenPhone: (data.reporter && data.reporter.mobileNumber) || data.citizenPhone || "Not provided",
    status: data.status || "Submitted",
    assignedTechnicianId: data.assignedTechnicianId || data.assignedTechId || null,
    assignedTechId: data.assignedTechnicianId || data.assignedTechId || null,
    assignedTechName: data.assignedTechName || null,
    createdAt: data.createdAt || new Date().toISOString(),
    updatedAt: data.updatedAt || new Date().toISOString(),
    resolvedAt: null,
    repairNotes: "",
    resolutionPhoto: null,
    source: data.source || "YIT Campus Portal"
  };

  const newTicket = TicketModel.createTicket(rawTicket);

  // Store in DB as plain JSON
  const plainTicket = JSON.parse(JSON.stringify(newTicket));
  db.complaints.unshift(plainTicket);

  // Update pole status to faulty
  if (pole) {
    pole.status = "faulty";
  }

  // Add real-time notification
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `NOTIF-${Date.now()}`,
    title: "New Fault Reported",
    message: `Ticket ${newTicket.ticketId} logged at ${newTicket.campusLocation} by ${newTicket.reporter.fullName} (${newTicket.reporter.role}).`,
    category: "new_ticket",
    time: new Date().toISOString(),
    read: false,
    ticketId: newTicket.ticketId
  });

  writeDB(db);
  return newTicket;
}

function updateComplaint(ticketId, updates) {
  const db = readDB();
  const q = String(ticketId).trim().toUpperCase();
  const index = (db.complaints || []).findIndex(c => 
    (c._id && c._id.toUpperCase() === q) || 
    (c.ticketId && c.ticketId.toUpperCase() === q)
  );
  if (index === -1) return null;

  const complaint = db.complaints[index];
  const previousStatus = complaint.status;

  if (updates.campusLocation) {
    complaint.campusLocation = TicketModel.normalizeCampusLocation(updates.campusLocation);
    complaint.wardZone = complaint.campusLocation;
  }
  if (updates.wardZone || updates.ward) {
    complaint.campusLocation = TicketModel.normalizeCampusLocation(updates.wardZone || updates.ward);
    complaint.wardZone = complaint.campusLocation;
  }
  if (updates.urgencyLevel) complaint.urgencyLevel = updates.urgencyLevel;
  if (updates.priority) { complaint.urgencyLevel = TicketModel.normalizeUrgency(updates.priority); complaint.priority = complaint.urgencyLevel; }
  if (updates.issueType) complaint.issueType = updates.issueType;
  if (updates.address) complaint.address = updates.address;
  if (updates.description) complaint.description = updates.description;
  if (updates.photoUrl) complaint.photoUrl = updates.photoUrl;
  
  if (updates.assignedTechnicianId || updates.assignedTechId) {
    const techId = updates.assignedTechnicianId || updates.assignedTechId;
    complaint.assignedTechnicianId = techId;
    complaint.assignedTechId = techId;
    const tech = (db.technicians || []).find(t => t.id === techId);
    if (tech) complaint.assignedTechName = tech.name;
  }
  if (updates.assignedTechName) {
    complaint.assignedTechName = updates.assignedTechName;
  }

  if (updates.reporter) {
    complaint.reporter = { ...complaint.reporter, ...updates.reporter };
  }
  if (updates.repairNotes) complaint.repairNotes = updates.repairNotes;
  if (updates.resolutionPhoto) complaint.resolutionPhoto = updates.resolutionPhoto;

  if (updates.status) {
    complaint.status = TicketModel.normalizeStatus(updates.status);
  }

  complaint.updatedAt = new Date().toISOString();

  if (updates.status && updates.status !== previousStatus) {
    if (!complaint.history) complaint.history = [];
    complaint.history.push({
      status: complaint.status,
      timestamp: new Date().toISOString(),
      note: updates.statusNote || `Status updated from ${previousStatus} to ${complaint.status}.`,
      by: updates.updatedBy || "Campus Maintenance Staff"
    });

    if (complaint.status === 'Resolved') {
      complaint.resolvedAt = new Date().toISOString();
      if (complaint.poleId) {
        const pole = db.poles.find(p => p.id === complaint.poleId);
        if (pole) pole.status = "active";
      }

      // Add resolved notification
      if (!db.notifications) db.notifications = [];
      db.notifications.unshift({
        id: `NOTIF-${Date.now()}`,
        title: "Complaint Resolved",
        message: `Ticket ${complaint.ticketId || complaint._id} at ${complaint.campusLocation} marked as resolved.`,
        category: "resolved",
        time: new Date().toISOString(),
        read: false,
        ticketId: complaint.ticketId || complaint._id
      });
    } else if (complaint.status === 'In Progress') {
      if (complaint.poleId) {
        const pole = db.poles.find(p => p.id === complaint.poleId);
        if (pole) pole.status = "in_repair";
      }
    }
  }

  writeDB(db);
  return TicketModel.createTicket(complaint);
}

// Assign complaint to technician
function assignComplaint(ticketId, techId, note) {
  const db = readDB();
  const q = String(ticketId).trim().toUpperCase();
  const complaint = (db.complaints || []).find(c => 
    (c._id && c._id.toUpperCase() === q) || 
    (c.ticketId && c.ticketId.toUpperCase() === q)
  );
  if (!complaint) return null;

  const tech = (db.technicians || []).find(t => t.id === techId);
  if (!tech) return null;

  complaint.assignedTechnicianId = tech.id;
  complaint.assignedTechId = tech.id;
  complaint.assignedTechName = tech.name;
  complaint.status = "Assigned";
  complaint.updatedAt = new Date().toISOString();

  if (!complaint.history) complaint.history = [];
  complaint.history.push({
    status: "Assigned",
    timestamp: new Date().toISOString(),
    note: note || `Dispatched to ${tech.name} (${tech.designation || 'Technician'}, ${tech.phone}).`,
    by: "Estates & Maintenance Desk"
  });

  // Add notification
  if (!db.notifications) db.notifications = [];
  db.notifications.unshift({
    id: `NOTIF-${Date.now()}`,
    title: "Technician Dispatched",
    message: `Ticket ${complaint.ticketId || complaint._id} assigned to ${tech.name} (${tech.phone}).`,
    category: "assignment",
    time: new Date().toISOString(),
    read: false,
    ticketId: complaint.ticketId || complaint._id
  });

  writeDB(db);
  return TicketModel.createTicket(complaint);
}

// Dashboard statistics
function getStats() {
  const db = readDB();
  const poles = db.poles || [];
  const complaints = db.complaints || [];

  const totalPoles = poles.length;
  const activePoles = poles.filter(p => p.status === 'active').length;
  const faultyPoles = poles.filter(p => p.status === 'faulty').length;
  const inRepairPoles = poles.filter(p => p.status === 'in_repair').length;

  const totalComplaints = complaints.length;
  const pendingCount = complaints.filter(c => {
    const s = TicketModel.normalizeStatus(c.status);
    return s === 'Submitted' || s === 'Pending' || s === 'Under Review';
  }).length;
  const assignedCount = complaints.filter(c => TicketModel.normalizeStatus(c.status) === 'Assigned').length;
  const inProgressCount = complaints.filter(c => TicketModel.normalizeStatus(c.status) === 'In Progress').length;
  const resolvedCount = complaints.filter(c => TicketModel.normalizeStatus(c.status) === 'Resolved').length;
  const hazardCount = complaints.filter(c => {
    const u = TicketModel.normalizeUrgency(c.urgencyLevel || c.priority);
    const s = TicketModel.normalizeStatus(c.status);
    return u === 'Emergency Hazard' && s !== 'Resolved';
  }).length;

  // Calculate average resolution time in hours for resolved complaints
  const resolvedWithTimes = complaints.filter(c => TicketModel.normalizeStatus(c.status) === 'Resolved' && c.resolvedAt);
  let avgHours = 4.2; // Campus average benchmark
  if (resolvedWithTimes.length > 0) {
    const totalMs = resolvedWithTimes.reduce((acc, c) => {
      const diff = new Date(c.resolvedAt) - new Date(c.createdAt);
      return acc + (diff > 0 ? diff : 0);
    }, 0);
    avgHours = ((totalMs / resolvedWithTimes.length) / (1000 * 60 * 60)).toFixed(1);
  }

  const uptime = totalPoles > 0 ? ((activePoles / totalPoles) * 100).toFixed(1) : 96.5;

  // Breakdown by the 7 campus locations
  const locationBreakdown = {};
  TicketModel.CAMPUS_LOCATIONS.forEach(loc => {
    locationBreakdown[loc] = {
      totalPoles: poles.filter(p => p.campusLocation === loc || p.ward === loc).length,
      faults: complaints.filter(c => (c.campusLocation === loc || c.wardZone === loc) && TicketModel.normalizeStatus(c.status) !== 'Resolved').length,
      resolved: complaints.filter(c => (c.campusLocation === loc || c.wardZone === loc) && TicketModel.normalizeStatus(c.status) === 'Resolved').length
    };
  });

  return {
    institution: "Yenepoya Institute of Technology, Moodbidri",
    totalPoles,
    activePoles,
    faultyPoles,
    inRepairPoles,
    uptimePercent: uptime,
    totalComplaints,
    pendingCount,
    assignedCount,
    inProgressCount,
    resolvedCount,
    hazardCount,
    avgResolutionHours: avgHours,
    locationBreakdown
  };
}

// Add Feedback for resolved complaints
function addFeedback(ticketId, rating, feedbackText) {
  const db = readDB();
  const q = String(ticketId).trim().toUpperCase();
  const complaint = (db.complaints || []).find(c => 
    (c._id && c._id.toUpperCase() === q) || 
    (c.ticketId && c.ticketId.toUpperCase() === q)
  );
  if (!complaint) return null;

  complaint.rating = parseInt(rating) || 5;
  complaint.feedback = feedbackText || "Verified restored by student/faculty.";
  complaint.ratedAt = new Date().toISOString();

  const citizenName = complaint.reporter?.fullName || complaint.citizenName || "Reporter";
  if (!complaint.history) complaint.history = [];
  complaint.history.push({
    status: "Feedback Received",
    timestamp: new Date().toISOString(),
    note: `Rating recorded: ${complaint.rating}/5 stars - "${complaint.feedback}"`,
    by: citizenName
  });

  writeDB(db);
  return TicketModel.createTicket(complaint);
}

// Deep Analytics: Campus Location breakdown, Issue breakdown, and Green Energy / Carbon calculations
function getAnalytics() {
  const db = readDB();
  const complaints = db.complaints || [];
  const poles = db.poles || [];

  const byIssue = {};
  const byLocation = {};
  const byPriority = {};

  let ratingsSum = 0;
  let ratingsCount = 0;

  complaints.forEach(c => {
    const issue = c.issueType || 'Other';
    const loc = c.campusLocation || c.wardZone || 'Main College Building';
    const urgency = c.urgencyLevel || c.priority || 'Standard';

    byIssue[issue] = (byIssue[issue] || 0) + 1;
    byLocation[loc] = (byLocation[loc] || 0) + 1;
    byPriority[urgency] = (byPriority[urgency] || 0) + 1;

    if (c.rating) {
      ratingsSum += c.rating;
      ratingsCount++;
    }
  });

  // Calculate day burning energy metrics for campus
  const dayBurningComplaints = complaints.filter(c => 
    c.issueType && c.issueType.toLowerCase().includes('day') && TicketModel.normalizeStatus(c.status) !== 'Resolved'
  );

  let wastedWatts = 0;
  dayBurningComplaints.forEach(c => {
    const p = poles.find(pole => pole.id === c.poleId || pole.code === c.poleCode);
    wastedWatts += p ? p.wattage : 90;
  });

  const wastedKwhPerDay = ((wastedWatts * 8) / 1000).toFixed(2);
  const costPerKwh = 7.5; // Institutional educational tariff in Karnataka (MESCOM)
  const wastedCostPerMonth = (parseFloat(wastedKwhPerDay) * 30 * costPerKwh).toFixed(0);
  const co2KgPerMonth = (parseFloat(wastedKwhPerDay) * 30 * 0.82).toFixed(1);

  return {
    institution: "Yenepoya Institute of Technology, Moodbidri",
    campusLocations: TicketModel.CAMPUS_LOCATIONS,
    byIssue,
    byLocation,
    byWard: byLocation, // Alias
    byPriority,
    energyMetrics: {
      activeDayBurningCount: dayBurningComplaints.length,
      wastedKwhPerDay,
      wastedCostPerMonth,
      co2KgPerMonth
    },
    citizenSatisfaction: {
      averageRating: ratingsCount > 0 ? (ratingsSum / ratingsCount).toFixed(1) : "4.9",
      ratingsCount
    }
  };
}

// Notifications list
function getNotifications() {
  const db = readDB();
  return db.notifications || [];
}

// Mark notifications as read
function markNotificationsRead() {
  const db = readDB();
  if (db.notifications) {
    db.notifications.forEach(n => n.read = true);
    writeDB(db);
  }
  return true;
}

// Monthly Maintenance Report Generator
function getMonthlyReport(requestedMonth) {
  const db = readDB();
  const complaints = db.complaints || [];
  const poles = db.poles || [];
  const technicians = db.technicians || [];

  // Default to current month or specified month (e.g. '2026-11')
  const now = new Date();
  const targetMonth = requestedMonth || `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  // Filter complaints created in that month
  const monthComplaints = complaints.filter(c => {
    const created = c.createdAt || '';
    return created.startsWith(targetMonth);
  });

  const totalReported = monthComplaints.length;
  const resolvedInMonth = monthComplaints.filter(c => TicketModel.normalizeStatus(c.status) === 'Resolved');
  const totalResolved = resolvedInMonth.length;
  const resolutionRate = totalReported > 0 ? ((totalResolved / totalReported) * 100).toFixed(1) : "100.0";

  // Location-wise breakdown
  const locationStats = TicketModel.CAMPUS_LOCATIONS.map(loc => {
    const locComplaints = monthComplaints.filter(c => c.campusLocation === loc || c.wardZone === loc);
    const locResolved = locComplaints.filter(c => TicketModel.normalizeStatus(c.status) === 'Resolved').length;
    const totalPolesInLoc = poles.filter(p => p.campusLocation === loc || p.ward === loc).length;
    return {
      location: loc,
      totalPoles: totalPolesInLoc,
      faultsReported: locComplaints.length,
      faultsResolved: locResolved,
      pending: locComplaints.length - locResolved
    };
  });

  // Issue types breakdown
  const issueBreakdown = {};
  TicketModel.ISSUE_TYPES.forEach(issue => {
    issueBreakdown[issue] = monthComplaints.filter(c => c.issueType === issue).length;
  });

  // Electrician workload
  const technicianStats = technicians.map(tech => {
    const assigned = monthComplaints.filter(c => c.assignedTechnicianId === tech.id || c.assignedTechId === tech.id);
    const resolved = assigned.filter(c => TicketModel.normalizeStatus(c.status) === 'Resolved');
    return {
      id: tech.id,
      name: tech.name,
      designation: tech.designation || 'Technician',
      assigned: assigned.length,
      resolved: resolved.length
    };
  });

  // Energy savings calculation
  const energySavedKwh = (totalResolved * 2.5 * 30).toFixed(1);
  const costSavedInr = (parseFloat(energySavedKwh) * 7.5).toFixed(0);

  return {
    institution: "Yenepoya Institute of Technology, Moodbidri",
    department: "Estates & Maintenance Division",
    affiliation: "Approved by AICTE, Affiliated to VTU Belagavi",
    month: targetMonth,
    generatedAt: new Date().toISOString(),
    totalPoles: poles.length,
    activePoles: poles.filter(p => p.status === 'active').length,
    uptimePercent: poles.length > 0 ? ((poles.filter(p => p.status === 'active').length / poles.length) * 100).toFixed(1) : "98.0",
    totalReported,
    totalResolved,
    resolutionRate: `${resolutionRate}%`,
    averageResolutionHours: "3.8",
    energySavedKwh,
    costSavedInr,
    locationStats,
    issueBreakdown,
    technicianStats,
    complaints: monthComplaints.map(c => ({
      ticketId: c.ticketId || c._id,
      campusLocation: c.campusLocation || c.wardZone,
      poleCode: c.poleCode,
      issueType: c.issueType,
      urgencyLevel: c.urgencyLevel,
      reporterName: c.reporter?.fullName,
      reporterRole: c.reporter?.role,
      status: c.status,
      assignedTech: c.assignedTechName || 'Unassigned',
      createdAt: c.createdAt,
      resolvedAt: c.resolvedAt
    }))
  };
}

module.exports = {
  initDB,
  getPoles,
  getPoleById,
  addPole,
  updatePole,
  getTechnicians,
  getComplaints,
  getComplaintByTicket,
  createComplaint,
  updateComplaint,
  assignComplaint,
  addFeedback,
  getStats,
  getAnalytics,
  getNotifications,
  markNotificationsRead,
  getMonthlyReport,
  // Ticket-specific aliases
  getTickets: getComplaints,
  getTicketById: getComplaintByTicket,
  createTicket: createComplaint,
  updateTicket: updateComplaint,
  assignTicket: assignComplaint
};
